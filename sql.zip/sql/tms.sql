-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 28, 2020 at 05:10 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `UserName` varchar(100) DEFAULT NULL,
  `Password` varchar(100) DEFAULT NULL,
  `updationDate` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `UserName`, `Password`, `updationDate`) VALUES
(1, 'admin', '0192023a7bbd73250516f069df18b500', '2017-05-13 11:18:49');

-- --------------------------------------------------------

--
-- Table structure for table `carrent`
--

CREATE TABLE `carrent` (
  `id` int(11) NOT NULL,
  `postBy` varchar(100) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `pick_up_point` varchar(100) NOT NULL,
  `pick_up_time` time NOT NULL,
  `destination_point` varchar(100) NOT NULL,
  `car_type` varchar(100) NOT NULL,
  `phone_number` varchar(50) NOT NULL,
  `approved` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `carrent`
--

INSERT INTO `carrent` (`id`, `postBy`, `user_name`, `pick_up_point`, `pick_up_time`, `destination_point`, `car_type`, `phone_number`, `approved`) VALUES
(7, 'mithunbmb45@gmail.com', 'Mithun Vakta', 'dvfdv', '13:00:00', 'cs', '', '01916868043', 'yes'),
(8, 'payelsarker989@gmail.com', 'Rakib Ahmed', 'Zero Point, Dhaka', '14:00:00', 'Monipur College, Rupnagar, Dhaka', 'Taxi/1', '01836338035', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `userEmail` varchar(100) NOT NULL,
  `comment` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `post_id`, `userEmail`, `comment`) VALUES
(1, 11, 'rana@gmail.com', 'Nice'),
(2, 11, 'rana@gmail.com', 'wow, nice work'),
(3, 16, 'rana@gmail.com', 'Thanks'),
(25, 15, 'rana@gmail.com', 'Wow, Cool'),
(26, 11, 'rana@gmail.com', 'Hello,'),
(27, 16, 'rana@gmail.com', 'abcd');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `message` varchar(2000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `user_name`, `phone_number`, `email`, `message`) VALUES
(1, 'Rakib Ahmed', '01836338035', '', 'hsxbhkhcaskj'),
(2, 'dcs', '01836338035', '', 'm,dfn'),
(3, 'Payel Rani', '01942947483', 'payelsarker989@gmail.com', 'I have some special request for reservation');

-- --------------------------------------------------------

--
-- Table structure for table `createpackage`
--

CREATE TABLE `createpackage` (
  `id` int(11) NOT NULL,
  `postedby` varchar(100) NOT NULL,
  `placename` varchar(100) NOT NULL,
  `placelocation` varchar(100) NOT NULL,
  `startlocation` varchar(100) NOT NULL,
  `packagetype` varchar(100) NOT NULL,
  `quantity` varchar(100) NOT NULL,
  `pricerange` varchar(100) NOT NULL,
  `specialrequirement` varchar(100) NOT NULL,
  `journeydate` date NOT NULL,
  `returndate` date NOT NULL,
  `mobilenumber` varchar(100) NOT NULL,
  `approved` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `createpackage`
--

INSERT INTO `createpackage` (`id`, `postedby`, `placename`, `placelocation`, `startlocation`, `packagetype`, `quantity`, `pricerange`, `specialrequirement`, `journeydate`, `returndate`, `mobilenumber`, `approved`) VALUES
(1, 'payelsarker989@gmail.com', 'Sonargaon', 'Narayanganj', 'Dhaka', 'Honeymoon', '4', '5000', 'Food', '2020-01-25', '2020-01-25', '01961698305', 'yes'),
(2, 'payelsarker989@gmail.com', 'dsd', 'ds', 'ds', 'ds', '5', '5000', 'food', '2020-01-29', '2020-01-31', '01942947483', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `createplace`
--

CREATE TABLE `createplace` (
  `id` int(11) NOT NULL,
  `division` varchar(20) NOT NULL,
  `placename` varchar(100) NOT NULL,
  `placetype` varchar(30) NOT NULL,
  `placelocation` varchar(50) NOT NULL,
  `placedetails` varchar(1000) NOT NULL,
  `routecost` varchar(500) NOT NULL,
  `placeimage` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `createplace`
--

INSERT INTO `createplace` (`id`, `division`, `placename`, `placetype`, `placelocation`, `placedetails`, `routecost`, `placeimage`) VALUES
(1, 'Dhaka', 'Sonargaon Museum', 'Historical Place', 'Sonargaon, Narayanganj', 'History and heritage sites are the open windows to the past of any country. Bangladesh, one of the most offbeat destinations in South Asia, has preserved both Muslim and Hindu heritage sites. Sonargaon, a city just one hour away from Dhaka, gives you a peek into the history of this medieval capital and how different cultures co-existed together.', 'You need to take a bus from Gulistan bus stop such as Doel, Sodesh, Borak etc. The road takes about one hour (depending on traffic in Dhaka) and one way costs 40 Tk by sodesh bus, 43tk by doel bus and 55tk by borak bus. From the bus stand in Sonargaon, you can hire a rickshaw till museum for 20 Tk and can also hire a local auto till museum for 10tk per person. Then finally you can reach the museum. The ticket price of museum is 30tk for per person.', '1dd0dfea63158a481091eb9cd947b130.jpg'),
(10, 'Sylhet', 'Tanguar Haowr ', 'Haowr', 'Tekerghat, Tahirpur , Sunamgonj', 'Tanguar haor, Sylheti; also called Tangua haor), located in the Dharmapasha and Tahirpur upazilas of Sunamganj District in Bangladesh, is a unique wetland ecosystem of national importance and has come into international focus. The area of Tanguar haor including 46 villages within the haor is about 100 square kilometres (39 sq mi) of which 2,802.36 ha2 is wetland. It is the source of livelihood for more than 40,000 people. The Government of Bangladesh declared Tanguar haor as an Ecologically Critical Area in 1999 considering its critical condition as a result of overexploitation of its natural resources. In 2000, the hoar basin was declared a Ramsar site - wetland of international importance. With this declaration, the Government is committed to preserve its natural resources and has taken several steps for protection of this wetland.', 'First of all Dhaka to Sunamganj by Bus, Fare 550 BDT\r\nRoute 1. \r\n\r\nDuring the monsoon from the city you can go directly to Tangua by  an engine boat or speed boat from the boat ferry. The engine boat takes 5 hours and the speed boat takes 2 hours. In that case, the engine boat costs BDT. 2,0 00/ - to 2,500 / - whereas the speed boat costs 7500 to 8000 BDT.\r\nThere is no nightly arrangement in the private system, but in the management of the government, 5km northeast, the Takerghat limestone minin', 'Tanguar-Haor-6-1024x683.jpg'),
(11, 'Sylhet', 'Niladrii Lake/ Shahid Siraj Lake', 'Lake', 'Tekerghat, Sunamgonj', 'Tekerghat limestone, was abandoned by Limestone Lake. Tourists know it as Niladri Lake. Its name is as beautiful as it is.The Location of Niladri Lake at Tekerghat village of North Sreepur Union under Tahirpur Upazila of Sunamganj district. The original name of Niladri Lake is Shaheed Siraj Lake. But in the travel community, this lake is known as Niladri Lake. However, local people know the place as the Tekerghat stone quarry. The combination of nice blue water, small and tall stairs, and mountains make the Niladri Lake worthless in beauty. It’s like losing in a blue kingdom. It seems, the place filled with the heavenly beauty. Many tourists call the place as Kashmir of Bengal.', 'The bus service of Mamun and Shyamoli Paribahan left for the Sunamganj from Saidabad bus stand in Dhaka and Ena Paribahan bus left the Mohakhali bus stand on a daily basis. These non-AC buses cost around 550 takas per ticket, and it takes about six hours to reach in Sunamganj. You can get the motorcycle for rent to go to Tekerghat in the new bridge area of Sunamganj City. If you take a motorcycle reserve, it will be charged from 300 to 400 taka. At the time of crossing the Jadukata River on the ', 'niladrii lake.jpg'),
(12, 'Sylhet', 'Barik Tila and Jadukata River and Shimul Bagan', 'River and Tila', 'Tahirpur, Sunamgonj', 'Jadukata River and Barik Tila are located in the same place. Jadukata River is another blue river at Sunamganj. Jadukata River is originated from the Meghalaya Hills of India & flows into Bangladesh. The river is very wide in the rainy season. If you visit in the winter, the mile long sandy bank will tell you about the fierceness of the river at rainy season. The color of the water is bluish. It’s very clear that you can almost see the river bed from the bank. You’ll find lot of large stones everywhere on the bank.\r\n\r\nThere is a hillock beside the river with 150 feet of height. It is said as Barik Tila or Barikka Tila by the local people. There is a pillar available at the hill which defines the border of Bangladesh and India. On top of it everything looks very small. The pillar between the hills is the border line between Bangladesh and India. You should be very careful about Indian BSF.\r\n\r\nThis river has produced lot of brunches & canals, but all of those joined with the Surma River.', 'You need to reach Sunamganj at the very beginning.  The GPS of the Jadukata River is (25°11’27.03?N, 91°14’56.05?E). You need to hire motor bike. It is around 300 taka for two people on a bike (same from Sunamganj town). It will take 60-80 minutes to reach the beautiful river.', 'barekkar tila.jpg'),
(13, 'Sylhet', 'Surma River', 'River', 'Sylhet Sadar, Sylhet', 'Surma River rises as the barak on the southern slopes of the Naga-Manipur watershed. The Barak splits into two branches within Cachhar district of Assam in India. Surma, the northern branch, flows west and then southwest to Sylhet town. Beyond sylhet, it flows northwest and west to Sunamganj town; from there to southwest and then south to Madna, where it meets the kushiyara, the other branch of the Barak. It receives several rivers and streams flowing south from Meghalaya Plateau. From east to west they are the Lubha, Hari (Kushia), Goyain Gang (Chengar Khal), piyain, Bogapani, Jadukata, Shomeshwari and kangsa.', 'From Dhaka to Sylhet Kadamtoli by Bus, fare 470. then by Rickshaw to  kean Bridge fare 10 or 20 BDT.', 'Surma river.jpg'),
(14, 'Sylhet', 'Jadukata River', 'River', 'Jadukata River, Tahirpur,  Sunamgonj', 'Bangladesh is crisscrossed by rivers, and beautiful rivers are always an attraction for tourists. The Jadukata – one of the most beautiful rivers in Bangladesh – is situated in Laurergorh under Tahirpur Upazilla in Sunamgonj District. Previously called the Renuka, this river flows from the Meghalaya ranges. The shrine of Hazrat Shah Arefin (R) is situated beside the river. Spectacularly visible behind the shrine (in the rainy season) is a waterfall. On the other side of the river is a beautiful hill popularly known as Bariker Tilla, behind which there is a church. Beside the church is a narrow westward road that leads to the village of the Garo indigenous community. Past the Garo village is the Borochora Stone Quarry and Takerghat.', 'You need to reach Sunamganj at the very beginning.  You need to hire motor bike. It is around 300 taka for two people on a bike (same from Sunamganj town). It will take 60-80 minutes to reach the beautiful river.', 'jadukata river.jpg'),
(15, 'Sylhet', 'Chatak Cement Factory', 'Industry', 'Chatak, Sunamgonj', 'Chhatak Cement Factory, established in 1941, is one of the oldest industrial units in Bangladesh. Chhatak Cement Factory Ltd. manufactures cement. The company was formerly known as Assam Bengal Cement Company Limited. Chhatak Cement Factory Ltd. was founded in 1937 and is based in Dhaka, Bangladesh. The company operates as a subsidiary of Bangladesh Chemical Industries Corporation.\r\n\r\nIn order to raise production capacity from 1,35,000 tons to 2,33,000 tons, the 2nd phase of the expansion programme has been completed with financing from Asian Development Bank. The Factory uses limestone imported from Meghalaya, India and from its own quarry-Takerghat Limestone Mining Project.', 'It is located in Chhatak Upazila of Sunamganj district, Sylhet. It is a 32 km drive from Sylhet. You can take a ride by a CNG auto rickshaw or bus from Sunamganj Sadar Upazila to Chhatak.', 'Chatak cement.jpg'),
(16, 'Sylhet', 'Sunamganj Traditional Museum', 'Museum', 'DS Road, Ukilpara, Sunamganj', 'The heritage museum has begun its journey to a nearly 1,500-year-old court building built during the British period in the city of Sunamganj. A trip to the heritage museum to get to know Sunamganj and introduce the district to the countrymen. All the memories of the environment, natural resources, culture, liberation war have been collected in this museum. This is the first such museum in the country at the district level, the organizers said, is such an initiative to bring the traditional architecture and tradition of Haorachanal to a new generation. \r\nEntrepreneurs are hopeful that the heritage museum will be enriched day by day. The court building located on DS Road along the Surma river in Sunamganj municipality was built during the British period. The 150-year-old abandoned court building was on the verge of destruction.', 'Any vehicle that descends to Sunamganj on the rickshaw / auto / foot can reach the Sunamganj Heritage Museum if it goes before the old court.', 'Sunamganj oitijjo jadughor.jpg'),
(17, 'Sylhet', 'Home of Shah Abdul Karim', 'Museum', 'Dirai, Sunamganj', 'Shah Abdul Karim (15 February 1916 — 12 September 2009) was a Bangladeshi Baul musician. Dubbed \"Baul Samrat\", he was awarded the Ekushey Padak in 2001 by the Government of Bangladesh. Some of his notable songs include Keno Piriti Baraila Re Bondhu, Murshid Dhono He Kemone Chinibo Tomare, Nao Banailo Banailo Re Kon Mestori, Ashi Bole Gelo Bondhu and Mon Mojale Ore Bawla Gaan.[5] He referred to his compositions as Baul Gaan', 'Dhaka to Dirai by Bus.\r\nFrom Dirai Upazila during Hemanta by Riska 50 / - CNG 20 / - Motor Bike 50 / -, By Boats 20 / - BDT in the rain.', 'shah abdul karim.jpg'),
(18, 'Sylhet', 'Radharaman Dutta\'s memorial', 'Temple', 'Sadar upazila, Sunamganj', 'Radharaman Dutta (1833–1915), also spelt as Radha Raman Dutta, was an influential Sylheti dhamail music composer[1] and lyricist. A prominent Baul (mystic minstrel), Dutta\'s body of work has led him to be considered \"the father of dhamal songs\"; his music is widely performed by modern Bengali musicians.', 'From the Upazila Sadar by renting a car / rickshaw', 'Radharaman er somadhi.jpg'),
(19, 'Sylhet', 'Pagla Jame Masjid', 'Masque', 'South Sunamganj', 'Pagla Jame Masjid, known locally as Raypur Boro Masjid, is a mosque in the village of Raypur, Paschim Pagla, South Sunamganj, Sunamganj District, Bangladesh. It lies on the banks of the Mahashing River. It was built by a local businessman called Yasin Mirza', '\r\nFrom the Sunamganj Sadar road is short.', 'pagla mosjid.jpg'),
(23, 'Sylhet', 'Hason Raja Museum', 'Historical Place', 'Sadar upazila, Sunamganj', 'Hason Raja was born on 1854 in Sunamganj. His old house is situated at the bank of Surma River in the Tegharia area of Sunamganj Sadar. It is now been converted as a museum and a well known tourist place in the city.\r\nHason Raja was actually an aristocrat Zamindar. But he won a lot of people’s heart by writing an enormous number of lyrics. After listening to his song, famous poet Rabindranath Tagore send him wishful letter. His tomb was situated in their family graveyard in Gazir Dorga area, Sunamganj where his mothers tomb was there too.\r\nThe museum is situated only 5 minutes walking distance from the Sunamganj city center traffic point. Today his used utensils and other accessories are kept in this place.', 'It is located only 5 minutes walking distance away from the city center traffic point. After reaching at Sunamganj Sadar, you can take rickshaw to reach that museum.', 'hason rajar bari.jpg'),
(24, 'Sylhet', 'Shrine of Hazrat Shah Jalal', 'Historical Place', 'Dorga gate, Ambokhana, Sylhet', 'This fascinating and atmospheric shrine of the revered 14th-century Sufi saint Shah Jalal is one of Bangladesh\'s biggest pilgrimage sites. Housing a mosque (masjid) and the main tomb (mazar), the complex is accessed via an open staircase from the East Darga Gate entrance. Shah Jalal’s tomb is covered with rich brocade, and the space around it is illuminated with candles in the evenings, lending a magical feel. Non-Muslims can enter (dress conservatively). Shoes have to be removed at the steps. The saint\'s sword and robes are preserved within the mosque, but aren’t on display. You can also walk around the hillside graveyard behind the shrine, dotted with tombs. Being buried near the saint is considered a great honour. Women can enter the complex – there is even a special prayer hall for women here – but are not usually allowed to enter the shrine itself (doing so would mean passing through part of the mosque, which is out of bounds to women).\r\n\r\nThe pond at the northern end of the compl', 'Sylhet Kadamtoli by Bus then by Rickshaw rent 50, CNG rent 100 (reserved) to Dorga gate', 'shahjala majar.jpg'),
(25, 'Sylhet', 'Durga Bari and Echo Park', 'Temple', 'Baluchor, Sylhet', 'The temple of Shri Sri Durga Bhari there are idols and Shiva statues placed by Goddess Durga. Eco Park has a variety of animals with natural beauty of plants', 'If you want to go Sri Sri Durga Bari temple, rent a CNG or Rickshaw to Baluchor point. Fare 50 BDT. Then By CNG or RIckshaw you should go in front of the  Sylhet Agriculture University to Echo park, fare 50 BDT', 'echo park.jpg'),
(26, 'Sylhet', 'Jaflong', 'Tourist spot', 'Gowainghat, Sylhet', 'Jaflong is a hill station and tourist destination in the Division of Sylhet, Bangladesh. It is located in Gowainghat Upazila of Sylhet District and situated at the border between Bangladesh and the Indian state of Meghalaya, overshadowed by subtropical mountains and rainforests. jaflong is known for its stone collections and is home of the Khasiya tribe. Jaflong is a tourist spot in Sylhet division. It is about 60 km from Sylhet town and takes two hours drive to reach there. Jaflong located amidst tea gardens and hills. It is situated besides the river Sari in the lap of Hill Khashia.', 'From Sylhet Kadamtoli to Jaflong by Bus rent 70 tk, By CNG rent 100 tk , by leguna rent 70 tk (all rents are for single person in local vehicle)', 'jaflong.jpg'),
(27, 'Sylhet', 'Lala khal', 'Tourist spot', 'Lalakhal, Jaintapur Sylhet', 'Lalakhal,which is another top tourist attraction in Jaintapur Upazilla, is covered with hills, natural forests, tea gardens, and rivers under the Jainta Hill which comprises part of the Meghalaya Ranges of India. Flowing from the Indian part, the river Myntdu enters Lalakhal as the Saree and meets the river Guaiyan after passing Sarighat. Over a stretch of nearly 12 km of the river from Lalakhal to Sarighat, the colour of the water stays transparent green in winter (as well as in other seasons when it does not rain) due to the minerals flowing with water and the sandy river bed.', 'Route 1:\r\nTourists usually travel to Sarighat, which is 42 km away from Sylhet city centre, by road and then hire a boat to reach Lalakhal. The one-and-a-quarter hour (mechanised-) boat ride over this crystal green water with lush green hills on both sides of the river is a soothing sight for any nature lovers.\r\nRoute 2:\r\nIt is also possible to go to Lalakhal by Micro Bus or Private car. Not far from the Sari Bridge is an old structure which used to be a tavern named after ‘Iraboti’, the princes', 'lala khal.jpg'),
(28, 'Sylhet', 'Bholaganj Sada Pathor', 'Tourist spot', 'Volaganj, Sylhet.', 'Bholaganj Sada Pathor, around 35 kilometres away from the Sylhet city, has turned into a new destination for the tourists.\r\n\r\nThe beautiful place located at the end of Sylhet-Companiganj-Bholaganj highway attracts hundreds of tourists a day.\r\n\r\nThe best time to visit the amazing spot is between May and October, especially in summer season.\r\n\r\nTo go to Bholaganj Sada Pathor, the travel lovers have to make a journey of 280 km from Dhaka by bus. There are buses available, both air-conditioned (AC) buses and non-AC from Dhaka to Sylhet. There are also trains from Dhaka to Sylhet.', 'From Sylhet Kadamtoli, first of all you must go to Amborkhana by CNG or Rickshaw (reserved or local). Then you can rent CNG or Leguna for local or reserved transport. Local fare in CNG BDT 130 for only one trip. For reserved Transport the rent required 1200 BDT. From volagonj to go to White stone you must hire a boat, fare BDT 700-800.', 'volaganj.jpg'),
(29, 'Sylhet', 'Malinichora Tea Gurden', 'Tea gurden', 'Chowkidekhi, Sylhet', 'It is the oldest and largest tea garden in the subcontinent established in Sylhet in 1849 over an area of 1500 acres. It presents a panoramic view with the area covered by green plants at different levels. A pleasure for the eye.', 'Amborkhana point from Sylhet Kadamtoli by CNG or Rickshaw and then Malinichora Tea Gurden by CNG or Rickshaw whore total fare locally 100-150 tk. You can go by reserved vehicle where you should bargaining the CNG rent about 200-300 updown.', 'malinichora tea.jpg'),
(30, 'Sylhet', 'Lakkatura Tea Gurden', 'Tea gurden', 'Lakkatura, Sylhet', 'Lakkatura Tea Garden is situated near Osmani Airport in Chaukidhenki Upazila of Sylhet district. Green Banani is surrounded by the northern side of Sylhet city, the Lakkatura Tea Garden. It is an official tea garden under the National Tea Board. Its position across 1293 hectares or about 3200 acres. From the Amberkhana point of Sylhet, 1.5km forward towards the airport, you will see Lakshatura Tea Garden signboard. About 500,000 kg of tea is produced annually from one of the largest tea gardens of Bangladesh.', 'It will take 10 minutes to visit Lakkatura tea garden from Amberkhana point of Sylhet. In the public CNG, rent will be Tk 5-10, and 15-20 tk in rickshaw.', 'lakkatura.jpg'),
(31, 'Sylhet', 'Hakaluki Haowr', 'Haowr', 'Baralekha, Moulovibazar', 'Hakaluki Haor is a marsh wetland ecological system of Eastern Bangladesh in an area bordering Assam, India. It is one of Bangladesh’s largest and one of Asia’s larger marsh wetland resources. Some 190,000 people live in the surrounding Hakaluki Haor area.\r\n\r\nHakaluki Haor was designated an Ecologically Critical Area (ECA). It’s also a protected Ramsar site of international importance for the conservation and sustainable utilization of wetlands.\r\n\r\nThe surface area of Hakaluki Haor is 181.15 km2, of which 72.46 km2 (40.01%) is within the territory of Barlekha Upazila. The Haor is partly under the jurisdiction of Barlekha Upazila', 'You can reach to Moulvibazar from Dhaka only via bus directly. If you want to travel by train, you need to get off at Sreemangal station. Then you need to take a local bus or CNG to reach Moulvibazar. In case, you would like to fly to Moulvibazar, you have to reach sylhet first, then you can take a direct bus to Moulvibazar.\r\nHakaluki haowr is 65 km away from Moulvibazar Sadar Upazila. First, you have to reach Moulvibazar. From Moulvibazar you can take a CNG auto rickshaw.', 'hakaluki.jpg'),
(32, 'Sylhet', 'Ratargul Swamp Forest', 'Tourist spot', 'Ratargul, Sylhet', 'Ratargul Swamp Forest is a freshwater swamp forest located in Gowain River, Fatehpur Union, Gowainghat, Sylhet, Bangladesh. It is the only swamp forest located in Bangladesh and one of the few freshwater swamp forest in the world. The forest is naturally conserved under the Department of Forestry, Govt. of Bangladesh.\r\n\r\nIts area is 3, 325.61 acre including 504 acre declared as the animal sanctuary in 2015. It is known as the Amazon of Bangla and Sundarbans of Sylhet. This only swamp forest in Bangladesh is located 26 kilometres (16 mi) far from Sylhet. The forest\'s name comes from the word, \"Rata\" or \"Pati\" tree, used by the locals of Sylhet.\r\n\r\nThe evergreen forest is situated by the river Goain and linked with the channel Chengir Khal. Most of the trees growing here are the Millettia pinnata ( Koroch tree). The forest is submerged under 20–30 feet water in the rainy season. For the rest of the year, the water level is about 10 feet deep.', 'It is approximately 18.7 km away from Sylhet. You may take bus or CNG auto rickshaw and head towards Saklutikor road. Take rickshaw to reach there. Local fare from amborkhana per person 200 tk in CNG and reserved fare 500 BDT.', 'ratargul.jpg'),
(33, 'Sylhet', 'Bichanakandi', 'Tourist spot', 'Hadarpar, Gowainghat, Sylhet', 'Bichanakandi is one of outstanding geographical tourist place between India and Bangladesh border. You can see the flags of India standing there 100 feet’s away. Even you can see the beautiful waterfalls coming to Bichankandi from India. The water comes from the cloudy mountains to small rocks, and clean fresh water and all these things together make this place so breathable with green, mint natural views. A wooden bridge let tourist to move around from water line to up hills, so that their domestic animals can move easily.\r\nFrom different stones to mountains, open sky, fresh clean waters all these together make Bichanakandi is perfect beautiful place. This place is very comfortable to stay around. Whoever comes to visit this place usually fall in love with this marvelous, astonishing natural views. So come here and enjoy a delightful time in  Bichanakandi.\r\nBICHANAKANDI is more or less alike JAFLONG, where we find different sources of mines. But in winter Bichanakandi is not suitable ', 'You can come to shylet town by Bus or Train from anywhere, then you have to take a CNZ until HADAR Bazar. CNZ fare around 500 TK. Even from AMBARKHAN you can go there by taking a CNZ, there, one CNZ takes 4 passengers at a time and CNZ fare is 80 Tk per person. It takes one and half an hour. Landing HADAR Bazar you have to take a local boat to go BICHANAKANDI, boat fare around 400 – 500 Tk up-down. But due to shortages of boat local people ask more fare, so fix the price first, then enjoy the be', 'bichanakandi.jpg'),
(34, 'Sylhet', 'Shrine of Hz. Shahporan', 'Historical Place', 'Majortila, Sylhet', 'Hazrat Shah Paran was a Sufi saint of the Suhrawardiyya and Jalalia order. It is said that he was the son of a sister of Shah Jalal and was born in Hadramaut, Yemen. He was an accomplice of his uncle, Shah Jalal, with whom he arrived in India. In 1303 AD, He took part in the expedition of Sylhet which was led by Shah Jalal. After the conquest of Sylhet he established a khanqah at Khadim Nagar in Dakshingarh Pargana, about 7 km away from Sylhet town, where he started Sufi spiritual practices and activities. He played a significant role in propagating Islam and establishing Muslim rule in the Sylhet region.\r\n\r\nIt is unclear how and when he died, but he is buried near his khanqah. For centuries, large numbers of devotees have been visiting his tomb, a practice which continues even today. On the 4th, 5th and 6th day of Rabi-ul-Awal, the Urs of Hazrat Shah Paran takes place. His grave is located in a high hillock and it is carefully preserved at a place which is built with bricks and surrou', 'It is located 8 km from Sylhet Sadar City, Major Tila. You have to take CNG auto rickshaw or local bus to Major Tila from the main town (Bandar or amborkhana), where that mazar is located. The  rent is 15-30 BDT.', 'Shrine_of_Hazrat_Shah_Paran_Sylhet_Bangladesh_38.JPG'),
(35, 'Sylhet', 'Bithangal Akhra', 'Temple', 'Baniyachang, Habiganj', 'Bithangal Akhra is located at Baniachong , Habiganj. One of the pilgrimage places for sanatan people, this area is 12 km from Baniachang upazila headquarters. Bithangal village is situated in south-western Howar Hill. Its founder is Ramakrishna Goswami. He established the arena at that place in the sixteenth century, following his pilgrimage to the subcontinent. It has 120 rooms for 122 Vaishnav. There are different types of religious festivals in this arena. \r\nAmong these are the kirtan on the occasion of Bhola on the last day of Kartik, the fifth day of the Dol Purnima on the Purnima Tithi of Phalgun, the second day of the festival on the eighth Tithi of Chaitra, the second day of the festival, and the Baruni Mela, Aaruni month.\r\nAmong the sights of the arena are the white stone outposts weighing 20 gems, the bronze made of brass, the furnished chariot, the silver pot and the crown of gold. Built in imitation of medieval architecture, this arena is a must-see destination for tourists', 'From Habiganj to  Baniachong upozila by CNG, Auto ricksha or local bus. Then you must hire a CNG or rickshaw to go Bithangal Akhra', 'Bithangal Akhra.jpg'),
(36, 'Sylhet', ' Rema Calanga Wildlife Sanctuary', 'Tourist spot and Forest', 'Chunarughat, Habiganj', 'Rema-Kalenga Wildlife Sanctuary is a protected forest and wildlife sanctuary in Bangladesh. This is a dry and evergreen forest . It is located in the Chunarughat of Habiganj district. Rema-Kalenga Wildlife Sanctuary was established in 1982 and later expanded in 1996. Currently the wildlife sanctuary expands on an area of 1795.54 hectares as of 2009. This is one of the natural forests in Bangladesh that are still in good condition. However, indiscriminate theft of trees & deforestation pose threat on the sanctuary.\r\nRema Kalenga Wildlife Sanctuary is a reserved forest lies at the border of Bangladesh-India. There are some local inhabitants living inside the forest dispersedly. A Tipra (Tripura) tribal village is near at the border. This forest is rich with flora & fauna and a hideout for a number of rare animals of Bangladesh. It is also a great place for forest trekkers.', 'Rema-Kalenga Reserve Forest is located at the Chunarighat Upazila of Habiganj district, approximately 151 km away from Dhaka and 31 km away from Habiganj. You will have to head to Habiganj, after arriving at Habiganj by CNG auto rickshaw or bus to head towards Habiganj-Shayestaganj highway to reach Chunarighat Upazila where this beautiful place is located.', 'Remakalenga.jpg'),
(37, 'Sylhet', 'Satchari National Park', 'National Park', 'Satchori, Shreemongol', 'Satchari National Park, a total area of 243 hectare, is located in Habiganj, 55 km south-west of Sreemangal Upazila. Though it is less popular than Lawachhara rain forest, it has a higher diversity of plants and animals and far less human disturbance. There are seven streams; the origin of the name “Satchari” came from these seven streams. A fair number of hillock gibbons, fishing cats, jungle fowl, pygmy woodpeckers and adaptive pied hornbills are the major features of this park.', 'Satchari National Park is located at the Chunarighat Upazila of Habiganj district. You can take buses from Dhaka to go directly in Chunarighat Upazila. Also, you can travel Sylhet or Habiganj. From Habiganj, take local buses or other transports to reach that place', 'satchori uddan.jpg'),
(38, 'Sylhet', 'Humhum Waterfall', 'Waterfall', 'Razkandi, Moulovibazar', 'Hum Hum Waterfall is situated in Razkandi reserve forest in Moulvibazar District. It was discovered in 2009. It is actually a place where you can find the real taste of adventure. The height of the fall is about 135-160 feet. It would be the best to travel this place in rainy season to discover the unlimited beauty of the fall. It is a matter of wonder that most of the Bangladeshi people do not even know about the fall. You can go throw bus or train from Dhaka to Sreemangal. You can find some hotels there. The next step is to go kolabagan bosti. For going to kolabagan bosti, you need to hire a jeep.\r\n\r\nThe most important thing is you need to start your journey early in the morning about 5-6 am. Carrying Knife, torch, dry food, fresh water, saline, glucose, and fast aid is a must for everyone. Now a days, there are a lot of guides available who can help the tourists to reach Hum Hum. Take some bamboo sticks as a support for you to from kolabagan which will really helpful in the whole jo', 'To reach Hum Hum Waterfall, you have to trek 3-4 hours through the muddy paths and jungle. When you travel through the jungle, you surely can find the unlimited beauty created by the God. Leeches are waiting there eagerly for you and the worst thing is, you cannot escape from them. There are two ways to reach Hum Hum fall. The guide will suggest you which will better to follow.\r\n\r\nWhile trekking, you will find jhiri path which is full of water and stones. You need to pass the path very carefully', 'humhum.jpg'),
(39, 'Sylhet', 'Grand Sultan Tea Resort & Golf', 'Hotel and Resort', 'Srimongal', 'Grand Sultan Tea Resort & Golf, the one & only five star resort in the Sylhet region of Bangladesh. Equipped with all modern state of the art amenities and facilities, located in Srimongal (the tea capital of Bangladesh). This resort is the true combination of ultimate luxury, gracious hospitality and admirable greenery. Classified in 07 categories, GS welcomes you with 135 rooms and suites to meet all your expectations.', 'From Dhaka Kamalapur or Airport Railway Station to Srimangal Railway Station on the Upoban, Jayantika, Parabat or Kalni Express trains. You can go to Srimangal by train. From Chittagong, two trains named Paharika and Udayan Express run 3 days a week to Srimangal by train. 250 to 1100 BDT per train fare class.', 'sultan.jpg'),
(40, 'Sylhet', ' Lawachara National Park', 'Tourist spot and Forest', 'Lawachara, Shremongal', 'Lawachara is one of the major national park/sanctuary/reserve in Bangladesh. In 1997 Bangladesh government declared it A National Park. This forest is built by the British, the time of their rule in Indian Subcontinent. Lawachara is the most beautiful tropical forest. The park is named after a small narrow tributary, named ‘Lawachara’. Its previous name was ‘West Bhanugan’. Lawachara is also called a Bird Safari.', 'Lawachara is about 160 km (99 mi) northeast of Dhaka and 60 km (37 mi) from Sylhet. It is 8 kilometres (5.0 mi) from the town of Srimongal. From Srimongal there are CNG, autorickshaw or local Bus to go  Lawachara National Park', 'lauachora.jpg'),
(41, 'Sylhet', 'Madhobpur Lake and Tea Estate', 'Tourist spot', 'Madhabpur, Srimongal', 'Madhobpur Lake and Tea Estate is located in Kamalganj Upazila of Moulvibazar District. The pleasant natural Madhobpur Lake is surrounded by small hills (Tila). Most of the hills are planted with tea trees. The bank side of the lake is full of lotuses and lilies. The color of the lilies is bluish which adorns this place with a bluish sphere. The lake is surrounded by small hills.\r\n\r\nThe lake is so wide and it’s hard to cover the whole lake with your camera. There is always heavy wind blows surround the lake that made the water of the lake looks like a river or calm sea water. You might have seen such kind of magenta and white colored lilies before. It is so beautiful, and the lily looks like a bit glowing from far. It seems that someone Photoshoped the flowers for that glowings.', 'It is approximately 207 km away from Dhaka and 39.3 km away from Moulvibazar. Bus companies like Shohag, Hanif, Shamoli, TR travels operate towards to Srimangal from Dhaka. If you prefer rail, you can take Kalni Express, Parabat Express or Joyontika Express to Srimangal from Dhaka.\r\n\r\nAfter reaching Srimangal, you may take CNG auto rickshaw or bus and head towards Srimangal-Bhanugach road. You may reach Sylhet from Dhaka. The tea estate is 94.2 km away from main Sylhet town. After reaching Sylhe', 'madhabpur.jpg'),
(42, 'Sylhet', 'Baikka Beel Wetland Sanctuary', 'Tourist spot', 'Sreemongal', 'Baikka Beel Sanctuary is to protect and restore aquatic biodiversity (particularly fish and birds) in Hail Haor. A secondary aim is through the visitor facilities to enhance enjoyment of the site and understanding of nature, the value of wetlands and need for their conservation. The sanctuary and its facilities are a model that can encourage replication of similar sanctuaries elsewhere in the country. Baikka Beel is a 100 ha wetland sanctuary located in Hail Haor a large wetland seasonally extending from 3,000-12,000 ha in north-east Bangladesh.\r\n\r\nBaikka Beel comprises of open water with emergent vegetation (mostly lotus), and a fringe of native swamp forest planted in 5-8 years ago. Originally it was protected to conserve and restore fish and it supports about 90 species of fish, but populations of wintering water birds rapidly increased.\r\n\r\nSo far 141 bird species have been recorded in the sanctuary. Up to 9 Pallas’s Fish Eagles winter, Large flocks of ducks including up to 4,500 Fu', 'The sign on the main Moulvibazar-Srimangal road is right to you if you are coming from Moulvibazar, about 0.5 km to Bhairabganj Bazar. A tourist should start from Srimangal town, hire a CNG at station road, standard is 400-500 BDT for taking him/her to the Beel. You may take your own transport. A 4WD Jeep/SUV or similar vehicle is suggested. The country road is not suitable for sedans. You should take the road heading towards Moulvibazar.\r\n\r\nIf you drive for about 6 kilometers, you will find a s', 'baikka.jpg'),
(43, 'Sylhet', 'Madhabkunda Falls', 'Waterfall', 'Barlekha, Moulovibazar', 'Madhabkunda Waterfall and Eco Park is situated in Barlekha Upazila in Moulvibazar District of Sylhet Division. It is one of the largest waterfalls in Bangladesh. The waterfall is a popular tourist spot in Bangladesh. Big boulders, surrounding forest, and the adjoining streams attract many tourists for picnic parties and day trips. The 267 hectors Madhabkunda Eco Park (est. 2001) is located at Madhabkunda under Moulvibazar District. This area was declared as Eco Park with a view to conserve the Madhabkunda waterfall and surrounding biodiversity. The Madhabkunda Waterfall is the most attractive site of this Eco Park which is about 200 ft. (61 m) high. A section of ‘Khasia’ tribe lives in the forest villages of this area. They are engaged in some agro-economic activities in the forestland.', 'It is 80 km away from main Sylhet town. You can go to Madhabkunda by train, bus or in private transportation. For train, the nearest station is Kulaura. After arriving at Kulaura, CNG or car can be hired (BDT 400-1000) to go to Madhabkunda. The distance of Madhabkunda is 6-7 km from Barlekha Upazila. For bus, it is suggested to go to Moulvibazar or Barlekha and then take buses to Madhabkunda. There are several bus services available from Dhaka. There is a BDT 20 entry fee to the Eco Park and wat', 'madhabkunda.jpg'),
(44, 'Chittagong', 'Kaptai Lake', 'Lake', 'Kaptai, Rangamati ', 'Kaptai Lake is a beautiful blue man-made watery lake. The size of this Lake is approximately 11000 square kilometer, which was created as a reservoir when the Kaptai dam was built during the 1960. This amazing Lake was created by flooding valleys and plain lands between numerous hills all around the Lake. Kaptai has Bangladesh’s only hydro-electric project. The Kaptai Dam on the Karnaphuli River created for this purpose resulted in the Kaptai Lake. This created a charming view as forested hills and plateaus rise from beneath the beautiful Lake water.\r\n\r\nA stretch of road connects the tourist spots of Rangamati and Kaptai. The road goes deep into the hill tracts and displays the natural beauty and wildlife of the district Rangamati. The government of Bangladesh run Tourism Corporation and many private operators offer Kaptai Lake Cruise Tours, which is worth of it. Other scenic spots are also accessible through the waterways. Cruising on the Kaptai Lake is an enjoyable way of observing t', 'Kaptai Lake is located in Rangamati Sadar Upazila. After reaching at Rangamati, take local transport to visit this lake.\r\nSpeed ??boats and boats are available for rent on the reserve bazaar, Tobolchhari and tourist ferries. The freight rate is 1200-1500 / - per hour per speed boat and domestic boat is 500-800 / -. BDT.', 'kaptai lake.jpg'),
(45, 'Chittagong', 'Keokradong', 'Mountain', 'Ruma, Bandarban', 'Keokradong is the second highest mountain of Bangladesh, about 4,035 ft (1,230 meters) high from the sea level. It is situated 30 km away from the Ruma Sadar Upazila of Bandarban District. This remote area is full of natural beauty, consisting of small and big mountains and hills. This area is covered with dense forests, birds and animals.\r\n\r\nKeokradong is located on the border between Bangladesh and Myanmar. You may be surprised after seeing its beauty. This natural beauty may attract the mind of the adventurous people. It is visited by many adventurous tourists in winter. Dazzling beauty of green hill, cool fountains, zigzag paths, hilly road side, hide and seek game of clouds on the top of the hill; all of these are simply mind-blowing.', 'Travel from Bandarban to Ruma: You have to make a trip from Bandarban to Ruma Upazila by “Chander Gari” (public jeep) or a private vehicle.\r\n\r\nTravel from Ruma to Boga lake: From Ruma Bazar, you should hire public jeep (Chander Gari) up to Boga lake and it may take Tk. 2000-2500. Before going to Boga lake you have to register your name, contact address and other details in the respective security or Army camp, you will require a guide to reach Jadipai Jhorna. For the first day the guide will cha', 'keukradong.jpg'),
(46, 'Chittagong', 'Nilgiri', 'Mountain', 'Bandarban', 'Nilgiri is one of the tallest peaks and a beautiful tourist spot in Bangladesh. It is about 3500 feet high and situated at Thanci Thana. Close to this spot you can see Moro villages. Their colorful culture and life style might be an unexplored experience for you. In rainy season a spectacular scenery is created here, the whole spot is covered with the blanket of clouds. It is a nice place for campfire in rainy season. Most attractive time of the day is the dawn. It is better to stay during 7-18 dates of a lunar month to enjoy the moonlit night. You can also enjoy the artful course of Sangu River. Niligiri is managed by Army brigade of Bandarban.', 'Dhaka and Bandarban are linked by road. There are direct bus services available from Dhaka to reach Bandarban. You can hire a private jeep or auto rickshaw to go Nilgiri from Bandarban city through Bandarban-Thanchi road.', 'nilgiri.jpg'),
(47, 'Chittagong', 'Nilachal', 'Mountain', 'Sadar, Bandarban', 'Nilachal is a beautiful tourist place to Meghla Parjatan Complex, also known as tiger hill. It is maintained by district administration. Nilachal is special for spectacular view from the hill apex and taking photos.It is the nearest tourist spot from Bandarban, situated at Tiger para. It stands 2000 feet above sea level and 5 kilometer away from the Bandarban town. Total glance of Bandarban town and a vast photographic hillside can be seen from here.', 'Nilachal is just 5 kilometers away from Bandarban town. So you can hire a shared or private jeep (known as Chander Gari) or CNG auto rickshaw to go there.', 'nilachol.jpg'),
(48, 'Chittagong', 'Boga Lake', 'Lake', 'Sadar Upozila, Bandarban', 'Boga Lake, also known as Bagakain Lake, is the most beautiful natural lake in Bangladesh. It is 18 km away from Ruma Sadar Upazila in Bandarban. The area of this lake is about 15 acres. It is approximately 1800 feet above sea level. The color of its water is blue. Behind creation of this lake there are many mythological stories. Many tourist visit Boga lake mostly during winter. Localities of small tribe community like Bawm, Khumi can be found besides the Boga Lake. Strolling becomes difficult in the rainy season.The road from Ruma to Boga Lake is still under construction. You might be amazed looking at the big rocks lying in and out of the Boga Lake. You can have a camp fire beside the lake which might be an unbelievable and mind-blowing memory in your life.', 'You have to make a trip from Bandarban to Ruma by “Chander Gari” (public jeep) or a private vehicle. From Ruma you can hire public jeep upto Boga Lake. You can also walk to Boga Lake in winter season. It will require 6 hours to reach Boga Lake.', 'bogalake.jpg'),
(49, 'Chittagong', 'Chimbuk Hill', 'Mountain', 'Sadar Upozila, Bandarban', 'Chimbuk Hill is one of the highest hills in Bangladesh is one of the more familiar spots in Bandarban. It is just 26 kilometers away from Bandarban Sadar. Chimbuk hill is approximately 2500 feet high above the sea level. The road is zigzag here. It will be charming to ride in a jeep. While your jeep is moving through the various native villages, their simplicity in human expression will compel you to think about our ancestors struggle to maintain existence. They are as simple as nature.\r\n\r\nWhile looking down from Chimbuk, you will have the feelings of floating over the clouds. In a sunny day, you can see the cloud shades over the hills. The huge horizon of zigzag hills seem like waves of a sea. However, you can go to the nearly situated tribal villages at Chimbuk hill. You can learn the lifestyle of the tribal people. It will be a nice experience of your life if you can do so.', 'There are several ways to reach at Bandarban. The best available bus service is Soudia, S. Alam, Shaymoly, Unique, Dolphin etc. It will take around 9-10 hours to reach at the town from Dhaka. You can reach the Chimbuk hill using the Micro Bus, or any privately rental cars. You have to take permission from the Army or Police camp, but those are just for formalities. It will take around 1 to 1.5 hours to reach the Chimbuk hill from the town depending upon the weather.', 'chimbuk.jpg'),
(50, 'Chittagong', ' Cox\'s Bazar beach', 'Sea Beach', 'Cox\'s Bazar', 'Cox’s Bazar is a District under Chittagong Division, which is famous for its longest unbroken sandy sea beach. It is located 150 km south of the industrial port- Chittagong. Cox’s Bazar is considered as having the longest sea beach in the world, with a total of 121 kilometer long. The name Cox’s Bazar was derived from its founder, Captain Cox. He founded the very attractive beach in 1798. Then the Cox’s Bazar beach started only as a small port and health resort.\r\n\r\nThough the beach is considered to be the longest beach in the world, it has been the least crowded among the other beaches. Here, visitors can enjoy the relaxing breeze of the Bay of Bengal Sea and the peacefulness of the place. The Cox’s bazar beach certainly has the finest leisure it can offer to each of its visitors. People can take a timely stroll along the lengthened stretch of the beach and enjoy the view of the amazing seascape. Visitors can also enjoy water sport activities like scuba diving, surfing, and try some bo', 'You may come to Cox’s Bazar by bus or air directly. There are several bus services available from Dhaka to Cox’s Bazar. Bus fare is around BDT 650-900 non-A/C and BDT 1200-1800 A/C . The journey is near about 8-10 hours. As well as Bangladesh Biman, United Air, Regent Air has domestic flights for Dhaka to Cox’s Bazar.\r\nFrom cox’s bazar you can easily reach to the Laboni, Kolatoli and Inani point by Rickshaw or Auto Rickshaw.', 'coxbazar.jpg'),
(51, 'Chittagong', 'St. Martin\'s Island', 'Sea Beach', 'Teknaf, Cox\'s Bazar', 'Saint Martin Bangladesh, in the Chittagong Division, is the only coral island of the country.  The local people call this tiny island “NarikelZinjira” meaning coconut island in their native language because of the abundant coconut growing here. The island is located in the southernmost part of mainland just at the river mouth of Naf river.\r\n\r\nThis landmark demarcates as the international borderline between Bangladesh and Myanmar. Somebody named it “Daruchini Dwip” for the surrounding naturally beautiful scenery and crystal clear blue water of the Bay of Bengal.Unlike the long sandy beach of Cox’s Bazar, you can walk around this entire small island.\r\n\r\nUsually, tourists take off for serene beach of Saint Martin island Bangladesh to refresh themselves after merriment at Cox’s Bazar. I wanted to explore this untouched territory when I was there. So, one fine morning we got on a bus and headed for Saint Martin island Bangladesh.\r\nAround 250 years ago, first Arabian sailors settled down on ', 'The island gets its best weather from November to February.So, these are the main tourist season with the best weather conditions. \r\n From Cox\'s Bazar to Teknaf there are many of buses rent 200-500 per person. The island becomes full of life from 10 a.m. just as the ferries dock full of tourists. They move about across this place till 3 p.m. This is the time for the ferries to leave this place. The fare of the ferries or Lanch 600-1500.', 'st martin.jpg'),
(52, 'Chittagong', 'Sajek Valley', 'Mountain and Tourist Place', 'Sajek Union, Baghaichari Upozila, Rangamati', 'Sajek Valley is an emerging tourist spot in Bangladesh situated among the hills of Kasalong range of mountains in Sajek union, Baghaichhari Upazila in Rangamati District. The valley is 1,800 feet (550 m) above sea level. Sajek valley is known as the Queen of Hills & Roof of Rangamati. The hight of the peak is around 1800 ft from the sea level. The name Sajek has come from the Sajek River. The valley is only 8 km far from Mijoram, India. Mostly from the beginning of the June to the end of September is the best time to visit this natural beauties.', 'Though Sajek valley is situated in the district of Rangamati. From Khagrachhari, it takes 7 hours from Dhaka to Khagrachhari, Then rent a Chander Garito reach Baghaichhari Bazar via Dighinala within 10 am or 3 pm because from baghaichhori bazar to Kasalong range army cars will escort you. It needs around 2 hours to reach Baghaichhari bazar and then up to 1.5 hours to reach the valley.', 'sajek.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `imageid` int(11) NOT NULL,
  `postBy` varchar(100) NOT NULL,
  `imagename` varchar(100) NOT NULL,
  `imagedescription` varchar(1000) NOT NULL,
  `image` varchar(1000) NOT NULL,
  `approved` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`imageid`, `postBy`, `imagename`, `imagedescription`, `image`, `approved`) VALUES
(21, '', 'Teknaf', 'This is Naff River. The ship is going to Saint Martin from Teknaf via Naff River.', 'slider1.jpg', 'yes'),
(22, '', 'Sajek Valley', 'This is most popular place known as Sajek Valley. Its also known as Queen of Hills & Roof of Rangamati.', 'slider6.jpg', 'yes'),
(25, '', 'Saint Martin', 'This is only one Coral Island in Bangladesh. ', 'slider2.jpg', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `hotel`
--

CREATE TABLE `hotel` (
  `hotelid` int(11) NOT NULL,
  `hotelname` varchar(100) NOT NULL,
  `hotellocation` varchar(100) NOT NULL,
  `hoteltype` varchar(100) NOT NULL,
  `hotelfeatures` varchar(100) NOT NULL,
  `hoteldetails` varchar(1000) NOT NULL,
  `hotelimage` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hotel`
--

INSERT INTO `hotel` (`hotelid`, `hotelname`, `hotellocation`, `hoteltype`, `hotelfeatures`, `hoteldetails`, `hotelimage`) VALUES
(1, 'Hotel Shalimar Int\'l', '2/A NORTH KAMOLAPUR, BESIDE BRTC, DHAKA, 1217', '3-Star', 'Free Wifi/Non-smoking rooms/Restaurant/Room service/Currency exchange/Laundry Service', 'Single Room(1 single bed): BDT 1,276+BDT 210 (taxes and charges)/ \r\n     \r\nDeluxe Twin Room(2 double beds): BDT 3,232+BDT 533 (taxes and charges)/\r\n\r\nDeluxe Double Room(1 double bed): BDT 2,722+BDT 449 (taxes and charges)/\r\n\r\nStandard Double Room(1 double bed): BDT 2,211+BDT 364 (taxes and charges)/\r\n\r\nEconomy Double Room(1 double bed): BDT 1,914+BDT 315 (taxes and charges)', 'unnamed.jpg'),
(2, 'Radisson Blu Dhaka Water Garden', 'Airport road, 1206 Dhaka, Bangladesh', '5-Star', ' Swimming pool/WiFi/Airport shuttle/Free parking/Spa and wellness centre/Fitness centre/Bar', 'Superior Room(1 large double bed or 2 single beds): BDT 17,435+BDT 4,620 (taxes and charges)/     \r\nDeluxe Room(1 large double bed): BDT 29,768+BDT 7,888 (taxes and charges)/\r\nBusiness Double Room(1 double bed): BDT 29,768+BDT 7,888 (taxes and charges)\r\n', '232835662.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `id` int(11) NOT NULL,
  `postedBy` varchar(50) NOT NULL,
  `title` varchar(100) NOT NULL,
  `cost` double NOT NULL,
  `details` varchar(500) NOT NULL,
  `approved` varchar(3) NOT NULL,
  `image` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`id`, `postedBy`, `title`, `cost`, `details`, `approved`, `image`) VALUES
(9, 'rana@gmail.com', 'Another night', 50, 'aaaaaaaaaaaaaaaaa', 'yes', ''),
(11, 'rana@gmail.com', 'The last story', 50, 'aaaaaaaaa', 'yes', ''),
(12, 'rana@gmail.com', 'Another night', 10, 'cccccccccc', 'yes', ''),
(14, 'rana@gmail.com', 'Hello Django', 50, 'djjfyjy', 'yes', ''),
(15, 'rana@gmail.com', 'Hello World', 10, 'hhhhhhhhhhhhhh', 'yes', 'pep.JPG'),
(16, 'rana@gmail.com', 'a', 10, 'ttttttttttttttt', 'yes', 't1.JPG'),
(17, 'rakib1818@gmail.com', 'a', 2000, 'dsdggh', 'yes', '1.jpg'),
(18, 'payelsarker989@gmail.com', 'tataitala', 8000, 'good place', 'yes', 'slider6.jpg'),
(20, 'payelsarker989@gmail.com', 'df', 3000, 'fvd', 'yes', 'slider6.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `id` int(10) UNSIGNED NOT NULL,
  `type` varchar(15) DEFAULT NULL,
  `bedding` varchar(10) DEFAULT NULL,
  `place` varchar(10) DEFAULT NULL,
  `cusid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`id`, `type`, `bedding`, `place`, `cusid`) VALUES
(1, 'Superior Room', 'Single', 'Free', NULL),
(2, 'Superior Room', 'Double', 'Free', NULL),
(3, 'Superior Room', 'Triple', 'Free', NULL),
(4, 'Single Room', 'Quad', 'Free', NULL),
(5, 'Superior Room', 'Quad', 'Free', NULL),
(6, 'Deluxe Room', 'Single', 'Free', NULL),
(7, 'Deluxe Room', 'Double', 'Free', NULL),
(8, 'Deluxe Room', 'Triple', 'Free', NULL),
(9, 'Deluxe Room', 'Quad', 'Free', NULL),
(10, 'Guest House', 'Single', 'Free', NULL),
(11, 'Guest House', 'Double', 'Free', NULL),
(12, 'Guest House', 'Quad', 'Free', NULL),
(13, 'Single Room', 'Single', 'Free', NULL),
(14, 'Single Room', 'Double', 'Free', NULL),
(15, 'Single Room', 'Triple', 'Free', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `roombook`
--

CREATE TABLE `roombook` (
  `id` int(10) UNSIGNED NOT NULL,
  `Title` varchar(5) DEFAULT NULL,
  `FName` text DEFAULT NULL,
  `LName` text DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `National` varchar(30) DEFAULT NULL,
  `Country` varchar(30) DEFAULT NULL,
  `Phone` text DEFAULT NULL,
  `TRoom` varchar(20) DEFAULT NULL,
  `Bed` varchar(10) DEFAULT NULL,
  `NRoom` varchar(2) DEFAULT NULL,
  `Meal` varchar(15) DEFAULT NULL,
  `cin` date DEFAULT NULL,
  `cout` date DEFAULT NULL,
  `stat` varchar(15) DEFAULT NULL,
  `nodays` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `roombook`
--

INSERT INTO `roombook` (`id`, `Title`, `FName`, `LName`, `Email`, `National`, `Country`, `Phone`, `TRoom`, `Bed`, `NRoom`, `Meal`, `cin`, `cout`, `stat`, `nodays`) VALUES
(4, 'Mrs.', 'Tahasin', 'Ameen', 'tahasin@gmail.com', 'Bangladeshi', 'Bangladesh', '01647333806', 'Standard Double Room', 'Double', '2', 'Breakfast', '2020-01-29', '2020-01-31', 'yes', 2),
(5, 'Mr.', 'Mithun ', 'Vakta', 'mithunbmb45@gmail.com', 'Bangladeshi', 'Bangladesh', '01768420842', 'Economy Double Room', 'Double', '3', '3-Times', '2020-02-13', '2020-02-15', 'yes', 2),
(6, 'Mr.', 'Tahasin', 'Ameen', 'rakibahmed1818@gmail.com', 'Bangladeshi', 'Bangladesh', '01647333806', 'Deluxe Twin Room', 'Double', '4', 'Breakfast', '2020-01-30', '2020-01-31', 'yes', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblbooking`
--

CREATE TABLE `tblbooking` (
  `BookingId` int(20) NOT NULL,
  `PackageId` int(11) DEFAULT NULL,
  `booking_quantity` int(50) DEFAULT NULL,
  `package_price` int(50) DEFAULT NULL,
  `booking_totalprice` int(50) DEFAULT NULL,
  `UserEmail` varchar(100) DEFAULT NULL,
  `FromDate` varchar(100) DEFAULT NULL,
  `ToDate` varchar(100) DEFAULT NULL,
  `Comment` mediumtext DEFAULT NULL,
  `RegDate` timestamp NULL DEFAULT current_timestamp(),
  `status` int(11) DEFAULT NULL,
  `CancelledBy` varchar(5) DEFAULT NULL,
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `payment_status` varchar(20) DEFAULT NULL,
  `pac_number` int(50) DEFAULT NULL,
  `p_amount` int(50) DEFAULT NULL,
  `p_txid` varchar(256) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblbooking`
--

INSERT INTO `tblbooking` (`BookingId`, `PackageId`, `booking_quantity`, `package_price`, `booking_totalprice`, `UserEmail`, `FromDate`, `ToDate`, `Comment`, `RegDate`, `status`, `CancelledBy`, `UpdationDate`, `payment_status`, `pac_number`, `p_amount`, `p_txid`) VALUES
(22, 1, 4, 6000, 24000, 'payelsarker989@gmail.com', '2020-02-03', '2020-02-06', NULL, '2020-01-26 03:38:41', 0, NULL, '2020-01-26 04:06:13', 'paid', 186593233, 253311, '2144558851'),
(23, 1, 4, 6000, 24000, 'payelsarker989@gmail.com', '2020-02-03', '2020-02-06', NULL, '2020-01-26 04:06:35', 0, NULL, '2020-01-26 04:07:46', 'paid', 186326598, 23000, '2144558851'),
(24, 1, 4, 6000, 24000, 'payelsarker989@gmail.com', '2020-02-03', '2020-02-06', NULL, '2020-01-26 05:59:13', 1, NULL, '2020-01-26 06:00:21', 'paid', 1961698305, 2400, '2144558851'),
(25, 1, 4, 6000, 24000, 'payelsarker989@gmail.com', '2020-02-03', '2020-02-06', NULL, '2020-01-26 07:37:43', 1, NULL, '2020-01-26 07:39:45', 'paid', 1728262806, 2000, 'whnore'),
(26, 1, 4, 6000, 24000, 'payelsarker989@gmail.com', '2020-02-03', '2020-02-06', NULL, '2020-01-26 07:55:11', 0, NULL, NULL, 'pending', NULL, NULL, NULL),
(27, 1, 4, 6000, 24000, 'payelsarker989@gmail.com', '2020-02-03', '2020-02-06', NULL, '2020-01-26 08:05:55', 0, NULL, NULL, 'pending', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblenquiry`
--

CREATE TABLE `tblenquiry` (
  `id` int(11) NOT NULL,
  `FullName` varchar(100) DEFAULT NULL,
  `EmailId` varchar(100) DEFAULT NULL,
  `MobileNumber` char(10) DEFAULT NULL,
  `Subject` varchar(100) DEFAULT NULL,
  `Description` mediumtext DEFAULT NULL,
  `PostingDate` timestamp NULL DEFAULT current_timestamp(),
  `Status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblenquiry`
--

INSERT INTO `tblenquiry` (`id`, `FullName`, `EmailId`, `MobileNumber`, `Subject`, `Description`, `PostingDate`, `Status`) VALUES
(1, 'Payel', 'payelsarker989@gmail.com', '123', 'dsdf', 'gff', '2020-01-01 06:02:19', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblissues`
--

CREATE TABLE `tblissues` (
  `id` int(11) NOT NULL,
  `UserEmail` varchar(100) DEFAULT NULL,
  `Issue` varchar(100) DEFAULT NULL,
  `Description` mediumtext DEFAULT NULL,
  `PostingDate` timestamp NULL DEFAULT current_timestamp(),
  `AdminRemark` mediumtext DEFAULT NULL,
  `AdminremarkDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblissues`
--

INSERT INTO `tblissues` (`id`, `UserEmail`, `Issue`, `Description`, `PostingDate`, `AdminRemark`, `AdminremarkDate`) VALUES
(9, NULL, NULL, NULL, '2019-12-20 13:57:30', NULL, NULL),
(10, NULL, NULL, NULL, '2019-12-20 13:59:43', NULL, NULL),
(11, NULL, NULL, NULL, '2019-12-23 16:41:51', NULL, NULL),
(12, NULL, NULL, NULL, '2019-12-24 15:08:01', NULL, NULL),
(13, NULL, NULL, NULL, '2019-12-24 15:09:46', NULL, NULL),
(14, NULL, NULL, NULL, '2019-12-26 09:14:55', NULL, NULL),
(15, NULL, NULL, NULL, '2019-12-26 11:39:22', NULL, NULL),
(16, NULL, NULL, NULL, '2019-12-29 14:32:32', NULL, NULL),
(17, NULL, NULL, NULL, '2019-12-31 07:25:13', NULL, NULL),
(18, NULL, NULL, NULL, '2019-12-31 07:53:45', NULL, NULL),
(19, NULL, NULL, NULL, '2020-01-01 07:05:14', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblpages`
--

CREATE TABLE `tblpages` (
  `id` int(11) NOT NULL,
  `type` varchar(255) DEFAULT '',
  `detail` longtext DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblpages`
--

INSERT INTO `tblpages` (`id`, `type`, `detail`) VALUES
(1, 'Terms', ''),
(2, 'privacy', '<span style=\"color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px; text-align: justify;\"></span>'),
(6, 'car_rent', NULL),
(7, 'blog', NULL),
(3, 'touristplaces', '										<span style=\"color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px; text-align: justify;\">\r\n<li>Dhaka</li>\r\n<li>Chittagong</li>\r\n<li>Sylhet</li>\r\n<li>Barisal</li>\r\n<li>Rajshahi</li>\r\n<li>Khulna</li>\r\n<li>Rangpur</li>\r\n<li>Mymenshing</li>\r\n</span>');

-- --------------------------------------------------------

--
-- Table structure for table `tbltourpackages`
--

CREATE TABLE `tbltourpackages` (
  `PackageId` int(11) NOT NULL,
  `PackageName` varchar(200) DEFAULT NULL,
  `PackageType` varchar(150) DEFAULT NULL,
  `StartLocation` varchar(256) DEFAULT NULL,
  `PackageLocation` varchar(100) DEFAULT NULL,
  `JourneyDate` date DEFAULT NULL,
  `ReturnDate` date DEFAULT NULL,
  `PackagePrice` int(11) DEFAULT NULL,
  `PackageFetures` varchar(255) DEFAULT NULL,
  `PackageDetails` mediumtext DEFAULT NULL,
  `PackageImage` varchar(100) DEFAULT NULL,
  `Creationdate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbltourpackages`
--

INSERT INTO `tbltourpackages` (`PackageId`, `PackageName`, `PackageType`, `StartLocation`, `PackageLocation`, `JourneyDate`, `ReturnDate`, `PackagePrice`, `PackageFetures`, `PackageDetails`, `PackageImage`, `Creationdate`, `UpdationDate`) VALUES
(1, 'Saint Martin Trip', 'General', 'Dhaka', 'Saint Martin Island', '2020-02-03', '2020-02-06', 6000, 'Air Conditioning ,Balcony / Terrace,Cable / Satellite / Pay TV available,Ceiling Fan,Hairdryer', 'We are starting our journey from saydabad bus stand of shyamoli at 8pm. At 10pm we wll arrange dinner for you. Then next day morning we reach on Tecknaf. In Tecknaf we will arrange breakfast. After completing breakfast we will prepare for going to ship Keari Sinbad. At 9:30am the ship will go. Then around 2/3hr later we will our destination Saint Martin Island.\r\n\r\n                                    \r\n', 'slider3.jpg', '2017-05-13 14:23:44', '2020-01-27 04:14:38'),
(2, 'Sajek Velly', 'Honeymoon Package', 'Chittagong', 'Sajek velly', '2020-02-12', '2020-02-16', 10000, 'Luxury Service', 'Though Sajek valley is situated in the district of Rangamati. From Khagrachhari, it takes 7 hours from Dhaka to Khagrachhari, Then rent a Chander Garito reach Baghaichhari Bazar via Dighinala within 10 am or 3 pm because from baghaichhori bazar to Kasalong range army cars will escort you. It needs around 2 hours to reach Baghaichhari bazar and then up to 1.5 hours to reach the valley.', 'slider6.jpg', '2017-05-13 15:24:26', '2020-01-14 22:27:38'),
(3, 'Jaflong Trip', 'Couple Package', 'Dhaka', 'Sylhet', '2020-02-01', '2020-02-05', 6000, '', '', 'maxresdefault.jpg', '2017-05-13 16:00:58', '2020-01-14 22:29:46'),
(4, 'Kaptai Lake', 'Family', 'Dhaka', 'Chittagong', '2020-02-01', '2019-12-03', 3000, 'Beautiful Place', '', 'web-rangamati-syed-zakir-hossai-1540382280927-1547127273108.jpg', '2017-05-13 22:39:37', '2020-01-28 07:07:03'),
(5, 'Sitakunda Botanical Garden & Eco-park', 'General', 'Dhaka', 'Chittagong', '2020-02-14', '2020-02-16', 2500, 'Excellent Service', '', 'Sitakunda-Botanical-Garden-.jpg', '2017-05-13 22:42:10', '2020-01-28 07:08:55'),
(6, 'Bandorban Trip', 'Family', 'Dhaka', 'Bandorban', '2020-02-13', '2020-02-16', 5000, 'Frree wifi, pickup and drop etc', '', 'bandarban.jpg', '2017-05-14 08:01:08', '2020-01-14 22:31:49');

-- --------------------------------------------------------

--
-- Table structure for table `tblusers`
--

CREATE TABLE `tblusers` (
  `id` int(11) NOT NULL,
  `UserType` text NOT NULL,
  `FullName` varchar(100) NOT NULL,
  `MobileNumber` char(20) NOT NULL,
  `Address` text NOT NULL,
  `EmailId` varchar(70) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `token_code` varchar(256) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `RegDate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblusers`
--

INSERT INTO `tblusers` (`id`, `UserType`, `FullName`, `MobileNumber`, `Address`, `EmailId`, `Password`, `token_code`, `status`, `RegDate`, `UpdationDate`) VALUES
(17, 'Travel Agent', 'Bappy Mahamud', '01916868043', 'Sonargaon', 'bappyjayed@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', NULL, NULL, '2019-12-24 15:09:46', NULL),
(18, 'Travel Agent', 'Ashrafujjaman Rana', '01XXXXXXXXX', 'Dhaka', 'rana@gmail.com', '4a7d1ed414474e4033ac29ccb8653d9b', NULL, NULL, '2019-12-26 09:14:55', NULL),
(19, 'User', 'Rezvee', '01XXXXXXXXX', 'Dhaka', 'rezvee@gmail.com', '4a7d1ed414474e4033ac29ccb8653d9b', NULL, NULL, '2019-12-26 11:39:22', NULL),
(20, 'Travel Agent', 'Payel', '01715318609', 'Sonargoan', 'payel@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', NULL, NULL, '2019-12-29 14:32:32', NULL),
(23, 'User', '3rrtgggg', '445', 'rrgg', 'njkjhhvf', '202cb962ac59075b964b07152d234b70', NULL, NULL, '2020-01-01 07:05:14', NULL),
(26, 'Travel Agent', 'Payel Rani', '01854123456', 'Sonargaon, Narayanganj', 'payelsarker989@gmail.com', '$2y$10$QSrrgBIHkRTlKNsJCnBPsumy5HWmmVnWzhSvXKckPTHHFSTNftU7e', '3a69ae3c535c1f26aec17bbbac664660', 'Y', '2020-01-10 17:35:59', '2020-01-27 04:29:12'),
(29, 'Travel Agent', 'Tahasin Ameen', '01967657464', 'Sonargaon, Narayanganj', 'afsarshohan60@gmail.com', '$2y$10$CO6dUx4kRpQ.IFLuOWUuROboFPKrfJFF2cueEJpFVbqU4iN.zrEu2', 'adaa634d91b3ea8288813f5bf0f6860f', NULL, '2020-01-12 04:29:29', NULL),
(33, 'Travel Agent', 'Rakib Ahmed', '01728262806', 'Tetuitola, Munshiganj', 'rakibahmed1818@gmail.com', '$2y$10$GrPZOVgJwf.9jQwZc9JMx.eueXYA8Qb7gDXe/wK3N.HD9PW6RuJ5a', 'ba5fbaa8a0e11bee0377743033852963', 'Y', '2020-01-12 07:36:10', '2020-01-12 18:11:40'),
(35, 'Travel Agent', 'Hasan Mahmud', '01521431843', 'Dhaka', 'hasanmahmud4277@gmail.com', '$2y$10$RAE5ps44/OPAMSs6dUkazurD.H9eFl8jaoA08OeQfMWr0Wc6ysbQW', '16a55ae36cb06a6a43620b796dd902d8', 'N', '2020-01-15 04:44:53', NULL),
(36, 'Tourist', 'Mithun Vakta', '01768420842', 'Madaripur', 'mithunbmb45@gmail.com', '$2y$10$KgywWjkrqTcmUSkZZavVFOlO.TNk94Pnf3VJUc4hM4Hn0CC0letWe', 'c05826434ad67313417891de813559d8', 'Y', '2020-01-16 20:21:38', '2020-01-16 20:22:56');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `carrent`
--
ALTER TABLE `carrent`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `createpackage`
--
ALTER TABLE `createpackage`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `createplace`
--
ALTER TABLE `createplace`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`imageid`);

--
-- Indexes for table `hotel`
--
ALTER TABLE `hotel`
  ADD PRIMARY KEY (`hotelid`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roombook`
--
ALTER TABLE `roombook`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblbooking`
--
ALTER TABLE `tblbooking`
  ADD PRIMARY KEY (`BookingId`);

--
-- Indexes for table `tblenquiry`
--
ALTER TABLE `tblenquiry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblissues`
--
ALTER TABLE `tblissues`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblpages`
--
ALTER TABLE `tblpages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbltourpackages`
--
ALTER TABLE `tbltourpackages`
  ADD PRIMARY KEY (`PackageId`);

--
-- Indexes for table `tblusers`
--
ALTER TABLE `tblusers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `EmailId` (`EmailId`),
  ADD KEY `EmailId_2` (`EmailId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `carrent`
--
ALTER TABLE `carrent`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `createpackage`
--
ALTER TABLE `createpackage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `createplace`
--
ALTER TABLE `createplace`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `imageid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `hotel`
--
ALTER TABLE `hotel`
  MODIFY `hotelid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `room`
--
ALTER TABLE `room`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `roombook`
--
ALTER TABLE `roombook`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tblbooking`
--
ALTER TABLE `tblbooking`
  MODIFY `BookingId` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `tblenquiry`
--
ALTER TABLE `tblenquiry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblissues`
--
ALTER TABLE `tblissues`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `tblpages`
--
ALTER TABLE `tblpages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `tbltourpackages`
--
ALTER TABLE `tbltourpackages`
  MODIFY `PackageId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tblusers`
--
ALTER TABLE `tblusers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
