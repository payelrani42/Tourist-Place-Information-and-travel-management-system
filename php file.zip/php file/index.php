<?php
session_start();
error_reporting(0);
include('includes/config.php');
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Tourism Management System</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<script type="applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/indexStyle.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
<link href="css/font-awesome.css" rel="stylesheet">
<!-- Custom Theme files -->
<script src="js/jquery-1.12.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>




<!---jscss--->


<!---jsss--->
        

<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>

    
<!--//end-animate-->
</head>
<body>
<?php include('includes/header.php');?>
<div class="">
	<div class="">
		
		<?php include('slider.php');?>
		
	</div>
</div>


<!--- rupes ---->

<!--- /rupes ---->




<!---holiday---->
<div class="container">
	<div class="holiday">
	



	
	<h3>Packages</h3>

					
<?php $sql = "SELECT * from tbltourpackages order by rand() limit 4";
$query = $dbh->prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{	?>
			<div class="rom-btm">
				<div class="col-md-3 room-left wow fadeInLeft animated" data-wow-delay=".5s">
					<img src="admin/pacakgeimages/<?php echo htmlentities($result->PackageImage);?>" class="img-responsive" alt="">
				</div>
				<div class="col-md-6 room-midle wow fadeInUp animated" data-wow-delay=".5s">
					<h4>Package Name: <?php echo htmlentities($result->PackageName);?></h4>
					<h6>Package Type : <?php echo htmlentities($result->PackageType);?></h6>
					<p><b>Package Location :</b> <?php echo htmlentities($result->PackageLocation);?></p>
					<p><b>Features</b> <?php echo htmlentities($result->PackageFetures);?></p>
				</div>
				<div class="col-md-3 room-right wow fadeInRight animated" data-wow-delay=".5s">
					<h5>BDT <?php echo htmlentities($result->PackagePrice);?></h5>
					<a href="package-details.php?pkgid=<?php echo htmlentities($result->PackageId);?>" class="view">Details</a>
				</div>
				<div class="clearfix"></div>
			</div>

<?php }} ?>
			
		
<div><a href="package-list.php" class="view">View More Packages</a></div>
</div>
			<div class="clearfix"></div>
	</div>
   
 <?php $j = 0; ?>

<!--event start-->
<div class="container">	  
    <h2 style="color: #34ad00; font-size: 2em;font-weight: 700;"><b>Event Lists</b></h2>	
<?php $sql = "SELECT * FROM post WHERE approved ='yes' order by post.id DESC, rand() limit 5";
$query = $dbh->prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{	
    $j = $j+1;
    ?>
			<div class="rom-btm" style="display: flex;">
				<div class="col-md-3 room-left wow fadeInLeft animated" data-wow-delay=".5s">
					<img src="images/post_image/<?php echo htmlentities($result->image);?>" class="img-responsive" alt="Image">
				</div>
                
				<div class="col-md-6 room-midle wow fadeInUp animated" data-wow-delay=".5s">
					<h4>Title : <?php echo htmlentities($result->title);?></h4>
					<h6>Cost : <?php echo htmlentities($result->cost);?></h6>
					<p style="margin-bottom: 10px;"><b>Description :</b> <?php echo htmlentities($result->details);?></p>
                    
                    <button onclick="plus(<?php echo $j ?>);" type="button" id="plus<?php echo $j ?>" class="commentBtn btn btn-primary"><i class="fa fa-plus" aria-hidden="true"></i>  See Comments</button>
                    
                    <button style="display: none;" onclick="minus(<?php echo $j ?>);" type="button" id="minus<?php echo $j ?>" class="commentBtn btn btn-primary"><i class="fa fa-minus" aria-hidden="true"></i>  Hide Comments</button>
                    
                    <div style="display: none;" id="cmSec<?php echo $j ?>" class="commentSection">
                        
<h3 style="margin-bottom: 5px;">Comments</h3>
<?php
    $postId = $result->id;
    //echo $postId;
    
    include 'includes/conn.php';
    $cQuery = "select * from comments where post_id like '$postId';";
    $cResult = mysqli_query($conn, $cQuery);
    
    $com = 0;
    
    while($row = mysqli_fetch_array($cResult)){
        $id = $row[0];
        $userEmail = $row[2];
        $comment = $row[3];
        
        $uQuery = "select * from tblusers where EmailId like '$userEmail';";
        $uResult = mysqli_query($conn, $uQuery);
        $uRow = mysqli_fetch_assoc($uResult);
        
        $name = $uRow["FullName"];
        
        
        echo '<p><b style="color: black;">'.$name.': </b>'.$comment.'</p> ';
//        echo '<p>'.$comment.'</p>';
        $com = $com+1;
        }
    if($com == 0){
        echo '<p>No Comments</p>';
    }
?>
                       

                    </div>

                </div>
                
                <?php
                if(isset($_SESSION["login"])){
                    echo '
    <form action="comment.php?id='.$postId.'" method="post" style="margin-top: 10px;">
      <div class="form-group">
        <input type="text" class="form-control" name="comment" placeholder="Add a new comment" required>
      </div>

      <button type="submit" class="btn btn-primary">Comment</button>
    </form>
                    
                    ';
                }
                ?>
        
            </div>
    
    

<?php }} ?>
    
    <script>
        function plus(n){
            var id = "cmSec"+n;
            document.getElementById(id).style.display = "block";
            document.getElementById("plus"+n).style.display = "none";
            document.getElementById("minus"+n).style.display = "block";
            //alert(id);
        }
        
        function minus(n){
            var id = "cmSec"+n;
            document.getElementById(id).style.display = "none";
            document.getElementById("plus"+n).style.display = "block";
            document.getElementById("minus"+n).style.display = "none";
            //alert(id);
        }
    </script>
    
    
    
    <div><a href="event-list.php" class="view">View More Events</a></div>
</div>
<br>
<!--events end-->

<!--- routes ---->


    

<?php include('includes/footer.php');?>
<!-- signup -->
<?php include('includes/signup.php');?>			
<!-- //signu -->
<!-- signin -->
<?php include('includes/signin.php');?>			
<!-- //signin -->
<!-- write us -->
<?php include('includes/write-us.php');?>			
<!-- //write us -->
</body>
</html>