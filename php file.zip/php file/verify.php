<?php
require_once 'class.mail.php';
include ('includes/config.php');


$user= new MAIL();


if(empty($_GET['id']) && empty($_GET['code'])){
    $user->redirect('../index.php');
}


if(isset($_GET['id']) && isset($_GET['code'])){
    $id= base64_decode($_GET['id']);
    
    
    $code= $_GET['code'];
    
    
    $statusY="Y";
    $statusN="N";
    
    
    $stmt = $dbh->prepare("SELECT id, status FROM tblusers WHERE id=:uid AND token_code=:code LIMIT 1");
    
    $stmt->execute(array(":uid"=>$id,":code"=>$code));
    
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if($stmt->rowCount()>0){
        if($row['status']==$statusN){
            $stmt=$dbh->prepare("UPDATE tblusers SET status =:status WHERE id=:uid");
            $stmt->bindparam(":status",$statusY);
            $stmt->bindparam(":uid",$id);
            
            $stmt->execute();
            $msg = "
            <div>
                <strong>Wow!</strong>
                
                Your Account is Now Activated: <a href='signinpage.php'>login here</a>
            </div>
            ";
        }
        else {
            $msg ="
            <div> <strong>sorry!</strong> Your account is allready activated: <a href='signinpage.php'>Login here</a> 
			</div>
            ";
        }
        
    }
    
	else {
		$msg = "
		<div>
		
		<strong> Sorry </strong>No account Found: <a href='signuppage.php'>signup</a>
		</div>
		
		";
	}
    
    
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<div>
	<?php 
		
		if(isset($msg)){
			echo $msg;
		}
		
		?>
	
	</div>
	
</body>
</html>
