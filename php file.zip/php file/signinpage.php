
<?php
session_start();
require_once 'class.mail.php';
$reg_user = new MAIL();
//error_reporting(0);
include('includes/config.php');


if(isset($_POST['login'])){


    $email= trim($_POST['email']);
    $upass = trim($_POST['password']);




            $stmt= $dbh-> prepare("SELECT * FROM tblusers WHERE EmailId=:email_id");


            $stmt->execute(array(":email_id"=>$email));


            $userRow = $stmt->fetch(PDO::FETCH_ASSOC);

            if($stmt->rowCount()==1){
                if($userRow['status']=="Y"){

                    //password_verify($password, $row['password'])
                    if(password_verify($upass, $userRow['Password'])){
                        //if($userRow['user_password']==md5($upass)){

                        //$_SESSION['user_id']=$userRow['user_id'];
                        //$_SESSION['user_email']=$userRow['user_email'];
                        $_SESSION['login']=$_POST['email'];
                        $error_msg="You are entered successfully.";
                        header("location: index.php?success");
                    }

                    else{

                        //header("location: login.php?error");

                        header("location: signinpage.php?error");


                        exit;

                    }
                }

                else{

                    header("location: signinpage.php?inactive");


                    exit;
                }

            }


            else{

                header("location: signinpage.php?error");


                exit;


            }



}


?>
<!DOCTYPE HTML>
<html>
<head>
<title>Signin Account</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<script type="applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/indexStyle.css" rel='stylesheet' type='text/css' />



 
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
<link href="css/font-awesome.css" rel="stylesheet">
<!-- Custom Theme files -->
<script src="js/jquery-1.12.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
        

<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->

<style>
*{
margin:0;
padding:0;
}
body{
	
	width:100%;
	margin-top:0px;
	
}
h1{
text-align:center;
margin-top: 0px;

color: green;
}
h2{
text-align:center;
padding:20px;
}
.register{
	margin-top: 50px;
    background:green;
    width: 600px;
    margin-left: 380px;
    color: white;
    font-size: 18px;
	padding:20px;
	border-radius:10px;
}
#register{
margin-left:90px;
}
label{
color:white;
font-family:sans-serif;
font-size:18px;
}
#name{
width: 378px;
    border: none;
    border-radius: 3px;
    outline: 0;
    padding: 7px;
}



#sub{
	margin-left: 90px;
width:200px;
padding:7px;
font-size:16px;
font-family:sans-serif;
font-weight:600;
border:none;
border-radius:3px;
outline:0;
}
input{
	color: black;
}
</style>



</head>
<body>

<br><br><br>

<?php

if(isset($msg)){
    echo $msg;
}
?>
<?php

if(isset($_GET['inactive'])){

    ?>

    <div>
        <strong>
            Sorry ! this Account is not activated. Go to your email inbox and active it.
        </strong>
    </div>

    <?php
}

?>

<?php

if(isset($_GET['error'])){
    ?>


    <div>
        <strong>
            Wrong Information

        </strong>

    </div>

    <?php
}



?>


<div class="register">
<h2>Sign In Here</h2>
<form method="post" id="register" action="signinpage.php">


<label>Email</label><br>
<input type="text" name="email" id="name" placeholder="Enter your Email"><br><br>
<label>Password</label><br>
<input type="password" name="password" id="name" placeholder="Enter your Password"><br><br>
    <a href="forgot_password.php" style="color: white;">Forgot Password?</a>
    <br><br>
<input type="submit" name="login" value="Submit" id="sub">
</form>
</div>

<!--end signup page-->   
<br><br>

<h3 style="text-align: center;"><a href="index.php" style="color: black;">Back to Home</a></h3>






</body>
</html>