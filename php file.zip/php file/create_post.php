<?php
session_start();
$userEmail = $_SESSION["login"];
?>
<html>
    <head>
        <title>Create Post</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <script type="applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
        <link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
        <link href="css/style.css" rel='stylesheet' type='text/css' />
        <link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
        <link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
        <link href='//fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
        <link href="css/font-awesome.css" rel="stylesheet">
        <!-- Custom Theme files -->
        <script src="js/jquery-1.12.0.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <!--animate-->
        <link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
        <script src="js/wow.min.js"></script>
            <script>
                 new WOW().init();
            </script>
        <!--//end-animate-->
    </head>
    
    <body>
        <?php include('includes/header.php');?>
        
        <div class="container">
            <?php
            $heading="";
            if(!isset($_REQUEST['title'])){
                $heading = "Create new post";
            }
            ?>
        
        <?php 
            if(isset($_REQUEST['title'])){
                $title = $_REQUEST['title'];
                $cost = $_REQUEST['cost'];
                $details = $_REQUEST['details'];
                
                $image= $_FILES["image"];

                /*echo $dp;*/

                //echo var_dump($image);

                $file_name = $image["name"];
                $tmp_name = $image["tmp_name"];
                //echo "<br>Image name: ".$file_name;

                move_uploaded_file($tmp_name, "images/post_image/$file_name");
                
                
                
                require "includes/config.php";
                
                $insertQuery = "INSERT INTO `post` (`id`, `postedBy`, `title`, `cost`, `details`, `approved`, `image`) VALUES (NULL, '$userEmail', '$title', '$cost', '$details', 'no', '$file_name')";
                
                
                
                $runQuery = $dbh->query($insertQuery);
                $heading = "Post Success!!!";
//                if ($runQuery === true) {
//                    $heading = "Post Success!!!";
//                    $dbh->close();
//                }else{
//                    $heading = "Something Error :(";
//                }
            }
        ?>
            <h2 class="text-center" style="color: #4db321; margin-top: 10px;"><?php echo $heading ?></h2>
        </div>
        
        <div class="container" style="margin-top:20px; margin-bottom:20px;">
        <form action="?" method="post" enctype="multipart/form-data">
          <div class="form-group">
            <label>Title:</label>
            <input type="text" class="form-control" name="title" placeholder="Enter post title" required>
          </div>
            
            <div class="form-group">
            <label>Cost:</label>
            <input type="text" class="form-control" name="cost" placeholder="Cost" required>
          </div>
            
          <div class="form-group">
            <label>Details:</label>
              <textarea type="text" class="form-control" name="details" placeholder="Details..." rows="10" required></textarea>
          </div>
            
            <div class="form-group">
            <label>Image:</label>
            <input type="file" class="form-control" name="image" required>
          </div>
          <button type="submit" class="btn btn-primary">Post</button>
        </form>
        </div>
        
        <?php include('includes/footer.php');?>
    </body>
</html>