

<?php
session_start();
error_reporting(0);
include('includes/config.php');
?>
<html>
    <head>
        <title>Contact Us</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <script type="applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
        <link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
        <link href="css/style.css" rel='stylesheet' type='text/css' />
        <link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
        <link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
        <link href='//fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
        <link href="css/font-awesome.css" rel="stylesheet">
        <!-- Custom Theme files -->
        <script src="js/jquery-1.12.0.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <!--animate-->
        <link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
        <script src="js/wow.min.js"></script>
            <script>
                 new WOW().init();
            </script>
        <!--//end-animate-->
    </head>
    
    <body>
        <?php include('includes/header.php');?>
        
        <div class="container">
            <br>
            <?php
            $heading="";
            if(!isset($_REQUEST['user_name'])){
                $heading = "Contact Us";
            }
            ?>
        
        <?php 
            if(isset($_REQUEST['user_name'])){
                $user_name = $_REQUEST['user_name'];
                
                
                $phone_number = $_REQUEST['phone_number'];
                $email = $_REQUEST['email'];
                $message = $_REQUEST['message'];


                
                require 'includes/conn.php';
                
                $insertQuery = "INSERT INTO `contact` (`id`, `user_name`, `phone_number`,`email`,`message` ) 
                VALUES (NULL, '$user_name', '$phone_number', '$email', '$message')";
                
                
                $result = mysqli_query($conn, $insertQuery);
                //$runQuery = $dbh->query($insertQuery);
                
                if ($result === true) {
                    $heading = "Message Send Successfully!!!";
                }else{
                    $heading = "Error: " .$mysql_qry . "<br>" .$conn->error;
                }
            }
        ?>
            <h2 class="text-center" style="color: #4db321; margin-top: 10px;"><?php echo $heading ?></h2>
        </div>
        
        <div class="container" style="margin-top:20px; margin-bottom:20px;">


        <form action="?" method="post">
          <div class="form-group">
            <label>User Name:</label>
            <input type="text" class="form-control" name="user_name" placeholder="user name" required>
          </div>
            
           
            
          
            
          <div class="form-group">
            <label>Phone Number:</label>
            <input type="text" class="form-control" name="phone_number" placeholder="enter valid phone number for contact you" required>
          </div>

          <div class="form-group">
            <label>Email:</label>
            <input type="email" class="form-control" name="email" placeholder="enter valid email for contact you" required>
          </div>
<div class="form-group">
          <label>Message:</label><br>
									<div>
										<textarea class="form-control" rows="5" cols="50" name="message" id="message" placeholder="your message" required></textarea> 
									</div>
</div>
     


<?php if($_SESSION['login'])
          {?>
            <br>
          <button type="submit" class="btn btn-primary">Send Message</button>
          <?php } else {?><ul style="list-style-type: none;">
              <li class="sigi" align="center" style="margin-top: 1%">
              <a href="signinpage.php"  class="btn-primary btn" >Login</a></li>
            </ul>
              <?php } ?>








        </form>
        </div>
        
        <?php include('includes/footer.php');?>
    </body>
</html>