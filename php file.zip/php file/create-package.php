<?php
session_start();
?>
<html>
    <head>
        <title>Create Package</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <script type="applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
        <link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
        <link href="css/style.css" rel='stylesheet' type='text/css' />
        <link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
        <link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
        <link href='//fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
        <link href="css/font-awesome.css" rel="stylesheet">
        <!-- Custom Theme files -->
        <script src="js/jquery-1.12.0.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <!--animate-->
        <link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
        <script src="js/wow.min.js"></script>
            <script>
                 new WOW().init();
            </script>
        <!--//end-animate-->
    </head>
    
    <body>
        <?php include('includes/header.php');?>
        <br><br>
        <div class="container">
            <?php
            $heading="";
            if(!isset($_REQUEST['placename'])){
                $heading = "Create your own package";
            }
            ?>
        
        <?php 
            if(isset($_REQUEST['placename'])){

                $placename = $_REQUEST['placename'];
                $placelocation = $_REQUEST['placelocation'];
                $startlocation = $_REQUEST['startlocation'];
                $packagetype = $_REQUEST['packagetype'];
                $quantity = $_REQUEST['quantity'];
                $pricerange = $_REQUEST['pricerange'];
                $specialrequirement = $_REQUEST['specialrequirement'];
                $journeydate = $_REQUEST['journeydate'];
                $returndate = $_REQUEST['returndate'];
                $mobilenumber = $_REQUEST['mobilenumber'];
                $userEmail= $_SESSION['login'];
                
                $no="no";

                require "includes/config.php";
                
                $query= "INSERT INTO createpackage (postedby, placename, placelocation, startlocation, packagetype, quantity,pricerange,specialrequirement,journeydate,returndate,mobilenumber,approved) VALUES (:useremail,:placename,:placelocation,:startlocation,:packagetype,:quantity, :pricerange,:specialrequirement,:journeydate,:returndate,:mobilenumber,:no)";

                $result = $dbh->prepare($query);
                $result->bindParam(':useremail',$userEmail,PDO::PARAM_STR);
                $result->bindParam(':placename',$placename,PDO::PARAM_STR);
                $result->bindParam(':placelocation',$placelocation,PDO::PARAM_STR);
                $result->bindParam(':startlocation',$startlocation,PDO::PARAM_STR);
                $result->bindParam(':packagetype',$packagetype,PDO::PARAM_STR);
                $result->bindParam(':quantity',$quantity,PDO::PARAM_STR);
                $result->bindParam(':pricerange',$pricerange,PDO::PARAM_STR);
                $result->bindParam(':specialrequirement',$specialrequirement,PDO::PARAM_STR);
                $result->bindParam(':journeydate',$journeydate,PDO::PARAM_STR);
                $result->bindParam(':returndate',$returndate ,PDO::PARAM_STR);
                $result->bindParam(':mobilenumber',$mobilenumber,PDO::PARAM_STR);
                $result->bindParam(':no',$no,PDO::PARAM_STR);

                ;
if ($result->execute()) {
                    $heading = "Package Created Successfully!!!";
                }
else{
                    $heading = "Error has occered ";
                }
            }
        ?>

            <h2 class="text-center" style="color: #4db321; margin-top: 10px;"><?php echo $heading ?></h2>
        </div>
        
        <div class="container" style="margin-top:20px; margin-bottom:20px;">
        <form action="?" method="post" enctype="multipart/form-data">
          <div class="form-group">
            <label>Place Name:</label>
            <input type="text" class="form-control" name="placename" placeholder="Enter place name where you want to go" required>
          </div>
            
            <div class="form-group">
            <label>Place Location:</label>
            <input type="text" class="form-control" name="placelocation" placeholder="Location of this place" required>
          </div>
            
          <div class="form-group">
            <label>Start Location:</label>
              <input type="text" class="form-control" name="startlocation" placeholder="Where do you go from?" required>
          </div>
            
            <div class="form-group">
            <label>Package Type:</label>
            <input type="text" class="form-control" name="packagetype" placeholder="Which type of package you need?" required>
          </div>

      <div class="form-group">
            <label>Quantity:</label>
            <input type="text" class="form-control" name="quantity" placeholder="How many people in your created package?" required>
          </div>

          <div class="form-group">
            <label>Price Range:</label>
            <input type="text" class="form-control" name="pricerange" placeholder="Enter your afordable price for per person" required>
          </div>

          <div class="form-group">
            <label>Special Requirement:</label>
            <input type="text" class="form-control" name="specialrequirement" placeholder="Enter your special requirement if you want to add" required>
          </div>

          <div class="form-group">
            <label>Journey Date:</label>
            <input type="date" class="form-control" name="journeydate" required pattern="\d{4}-\d{2}-\d{2}">
          </div>

          <div class="form-group">
            <label>Return Date:</label>
            <input type="date" class="form-control" name="returndate" required pattern="\d{4}-\d{2}-\d{2}">
          </div>

          <div class="form-group">
            <label>Mobile Number:</label>
            <input type="text" class="form-control" name="mobilenumber" placeholder="Enter your mobile number for contacting with you" required>
          </div>

          



          <?php if($_SESSION['login'])
          {?>
            
          <button type="submit" class="btn btn-primary">Create Package</button>
            
            <?php } else {?><ul style="list-style-type: none;">
              <li class="sigi" align="center" style="margin-top: 1%">
              <a href="signinpage.php"  class="btn-primary btn" >Login</a></li>
            </ul>
              <?php } ?>


        </form>
        </div>
        
        <?php include('includes/footer.php');?>
    </body>
</html>