<?php

session_start();
require_once 'class.mail.php';
include ('includes/config.php');

$user= new MAIL();

if(isset($_SESSION['login'])) {
	if($_SESSION['login']!=''){
        header('Location: index.php');
    }


}
if(isset($_POST['submit-btn'])){
	$email = $_POST['email'];
	
	$stmt = $dbh->prepare(" SELECT * FROM tblusers WHERE EmailId=:email LIMIT 1");
	$stmt->execute(array(":email"=>$email));
	
	$row = $stmt->fetch(PDO::FETCH_ASSOC);
	
	
	if($stmt->rowCount()==1){
		$id= base64_encode($row['id']);
		
		$code = md5(uniqid(rand()));
		
		$stmt= $dbh->prepare("UPDATE tblusers SET token_code=:token WHERE EmailId=:email");
		
		$stmt->execute(array(":token"=>$code, ":email"=>$email));
        $name=$row['FullName'];
		$message ="
		
		Hello , $name
		<br> <br>
		 We got request to reset your password, if you have done this then just click the following link to reset your password, if not just ignore this email.
		 
		 <br> <br>
		 
		 
		 <a href='http://localhost/projects/tms/reset.php?id=$id&code=$code'> Click here to reset your password</a> 
		 
		 <br> <br>
		 Thank you.
		
		
		";
		$subject ="Password Reset";
		
		$user->send_mail($email,$message,$subject);
		
		$msg ="
		<div>
		We have sent an email to $email. Please click on the password reset link in the email to generate new password.
		</div>
		
		";
		
	}
	
	else{
		$msg="
		
		<div>
		
		<strong> Sorry</strong>
		This email is not found.
		
		</div>
		
		
		";
	}
	
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Forgot Password</title>
</head>

<body>

    <div>
        <?php
		
		if(isset($msg)){
			echo $msg;
		}
		
		else{
			?>
        <div>
            Please enter your email address. You will receive a link to create a new password.
        </div>

        <?php
		
		}
		
		
		?>

    </div>

    <div>

        <form method="post" action="<?php echo $_SERVER['PHP_SELF'] ?>">

            <input type="email" placeholder="Enter your email address" name="email" required>
            <br><br>
            <input type="submit" name="submit-btn" value="Get your new password">


        </form>


    </div>

</body>

</html>
