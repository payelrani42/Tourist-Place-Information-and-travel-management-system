<?php
session_start();
error_reporting(0);
include('includes/config.php');
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Package List</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
<link href="css/font-awesome.css" rel="stylesheet">

    <link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="assets/css/style.css" type="text/css">
    <link rel="stylesheet" href="assets/css/owl.carousel.css" type="text/css">
    <link rel="stylesheet" href="assets/css/owl.transitions.css" type="text/css">
    <link href="assets/css/slick.css" rel="stylesheet">
    <link href="assets/css/bootstrap-slider.min.css" rel="stylesheet">
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="css/style.css" rel='stylesheet' type='text/css' />

<!-- Custom Theme files -->
<script src="js/jquery-1.12.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
    <script>
         new WOW().init();
    </script>
<!--//end-animate-->
</head>
<body>
<?php include('includes/header.php');?>
<!--- banner ---->
<div class="">
    <div class="container"> <h4 style="color: white;text-align: right;margin-right: 1%;margin-top: 2%;"><a href="create-package.php" style="color: green;">Create Package</a></h4>
        <h1 class="wow zoomIn animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: zoomIn;"></h1>
<!--
        <form  method="post" action="package-search-results.php">
            <div class="row">
                <div class="form-group col-md-4">
                    <label class="control-label" style="color: black;">From</label>
                    <input type="text" name="location_start" list="start_location" class="form-control gray_bg" id="station_from" value="all" required>
                </div>
                <div class="form-group col-md-4">
                    <label class="control-label" style="color: black;">To</label>
                    <input type="text" name="destination" list="destination" class="form-control gray_bg" id="to" value="all" required>
                </div>
                <div class="form-group col-md-4">
                    <label class="control-label" style="color: black;">Journey Date</label>
                    <input type="date" name="journey_date" list="packagedates" class="form-control gray_bg" id="to" value="all" required>
                </div>

                <div class="form-group col-md-4">
                    <label class="control-label" style="color: black;">Minimum Cost</label>
                    <input type="number" name="min_cost" list="mincost" class="form-control gray_bg" id="to" value="all" required>
                </div>

                <div class="form-group col-md-4">
                    <label class="control-label" style="color: black;">Maximum Cost</label>
                    <input type="number" name="max_cost" list="mincost" class="form-control gray_bg" id="to" value="all" required>
                </div>

                <div class="form-group col-md-4">
                    <label class="control-label" style="color: black;">Package Type</label>
                    <input type="text" name="package_type" list="packagetypes" class="form-control gray_bg" id="types" value="all" required>
                </div>
            </div>
            <div class="row">
                <div class="form-group" style="text-align:center;">
                    <button class="btn" type="submit" name="search_package" type="submit">Search Packege</button>

                    <datalist id="destination">
                        <?php
                        $sql = "SELECT * from  tbltourpackages ORDER BY PackageLocation ASC;";
                        $query = $dbh -> prepare($sql);
                        $query->execute();
                        $results=$query->fetchAll(PDO::FETCH_OBJ);
                        if($query->rowCount() > 0)
                        {
                        foreach($results as $result)
                        { ?>
                        <option value="<?php echo htmlentities($result->PackageLocation); ?>">
                            <?php  }?>
                    </datalist>

                    <datalist id="packagetypes">
                        <?php

                        foreach($results as $result)
                        { ?>
                        <option value="<?php echo htmlentities($result->PackageType); ?>">
                            <?php  }?>
                    </datalist>
                    <datalist id="start_location">
                        <?php

                        foreach($results as $result)
                        { ?>
                        <option value="<?php echo htmlentities($result->StartLocation); ?>">
                            <?php  }?>
                    </datalist>

                    <datalist id="mincost">
                        <?php

                        foreach($results as $result)
                        { ?>
                        <option value="<?php echo htmlentities($result->PackagePrice); ?>">
                            <?php  }?>
                    </datalist>


                    <datalist id="packagedates">
                        <?php

                        foreach($results as $result)
                        { ?>
                        <option value="<?php echo htmlentities($result->JourneyDate); ?>">
                            <?php  }}?>
                    </datalist>

                </div>
            </div>
        </form>
    </div>
</div>
-->

<?php include('package-list.php');?>


<!--- /banner ---->

<!--- /footer-top ---->
<?php include('includes/footer.php');?>
<!-- signup -->
         
<!-- //signu -->
<!-- signin -->
<?php include('includes/signin.php');?>         
<!-- //signin -->
<!-- write us -->
<?php include('includes/write-us.php');?>   
<!--- /footer-top ---->
        
<!-- //write us -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/interface.js"></script>
<script src="assets/switcher/js/switcher.js"></script>
<script src="assets/js/bootstrap-slider.min.js"></script>
<script src="assets/js/slick.min.js"></script>
<script src="assets/js/owl.carousel.min.js"></script>
</body>
</html>