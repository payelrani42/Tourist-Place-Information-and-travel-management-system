<?php

require_once('class.mail.php');

$user = new MAIL();
include ('includes/config.php');


if(empty($_GET['id']) && empty($_GET['code'])){
	header('Location: index.php');
}

if(isset($_GET['id']) && isset($_GET['code'])){
	
	
	$id= base64_decode($_GET['id']);
	
	$code= $_GET['code'];
	
	
	$stmt =$dbh->prepare("SELECT * FROM tblusers WHERE id=:uid AND token_code=:token");
	
	$stmt->execute (array(":uid"=>$id, ":token"=>$code));
	
	$rows = $stmt->fetch(PDO::FETCH_ASSOC);
	
	
	if($stmt->rowCount()==1){
		
		
		if(isset($_POST['reset-btn'])){
			$pass = $_POST['password'];
			
			$confirmpass=$_POST['confirm_password'];
			
			if($confirmpass!==$pass){
				$msg=" 
				<div>
				<strong> Sorry</strong>
				
				Password doesn't match.
				
				
				</div>
				
				";
				
				
			}
			else{
				
				$password = password_hash($confirmpass, PASSWORD_DEFAULT);
				
				//$password =md5($confirmpass);
				
				$stmt = $dbh->prepare("UPDATE tblusers SET Password=:upass WHERE id=:uid");
				
				
				$stmt->execute(array(":upass"=>$password, ":uid"=>$rows['id']));
				
				$msg="  
				<div> Password Changed.</div>
				";
				
				header("refresh:5; index.php");
			}
		}
	}
	
	else{
		$msg= "
		
		<div>
		No Account Found, Try again.
		</div>
		
		";
	}
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Password Reset</title>
</head>
<body>
	
	<div>
	<strong>Hello!</strong>
		
		<?php echo $rows['FullName']; ?> You are here to reset your forgetton password.
	
	</div>
	
	<div>
		
		<?php 
		if(isset($msg)){
			echo $msg;
	
} ?>
		
		<form method="post">
		
			<input type="password" placeholder="New Password" name="password" required>
			<input type="password" name="confirm_password" placeholder="Confirm Password" required>
			<input type="submit" value="Reset Your Password" name="reset-btn">
		
		</form>
	
	
	
	</div>
	
	
	
</body>
</html>





