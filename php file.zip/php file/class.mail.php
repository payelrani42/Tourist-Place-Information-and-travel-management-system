<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
error_reporting();
class MAIL {

	function send_mail($email,$message,$subject)
	{						
		require_once('PHPMailer/PHPMailer.php');
		require_once('PHPMailer/SMTP.php');
		require_once('PHPMailer/Exception.php');
		
		$mail = new PHPMailer(true);
		$mail->IsSMTP(); 
		$mail->SMTPDebug  = 0;
		$mail->SMTPAuth   = true;
		$mail->SMTPSecure = "ssl";
		$mail->Host       = "smtp.gmail.com"; 
		$mail->Port       = 465; 
		$mail->AddAddress($email);
        $mail->Username='payelsarker989@gmail.com';
        $mail->Password="niramish42&";
        $mail->SetFrom('payelsarker989@gmail.com','Travelandbd');
		$mail->AddReplyTo("payelsarker989@gmail.com","Travelandbd");
		$mail->Subject   = $subject;
		$mail->MsgHTML($message);
		$mail->Send();
	}

    public function test_input($data){

        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);

        $data = strip_tags($data);

        //$data = $this->dbcon->real_escape_string($data);

        return $data;
    }
}
