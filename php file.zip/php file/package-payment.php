<?php
session_start();
error_reporting(0);
include('includes/config.php');


if(isset($_POST['pay']))
{
$id=$_GET['id'];
$payment_status="paid";
$p_amount=$_POST['p_amount'];
$pac_number=$_POST['pac_number'];
$p_txid=$_POST['p_txid'];
$sql="UPDATE tblbooking set payment_status=:payment_status, p_amount=:p_amount, pac_number=:pac_number, p_txid=:p_txid WHERE BookingId=:bookingid";
$query = $dbh->prepare($sql);
$query->bindParam(':payment_status',$payment_status,PDO::PARAM_STR);
$query->bindParam(':p_amount',$p_amount,PDO::PARAM_STR);
$query->bindParam(':pac_number',$pac_number,PDO::PARAM_STR);
$query->bindParam(':p_txid',$p_txid,PDO::PARAM_STR);
$query->bindParam(':bookingid',$id,PDO::PARAM_STR);

if($query->execute()){

    $msg="Payment Information Sent to admin, please wait for approval.";


  header("refresh:2; package-search.php");
}
else{
    $error="Something went wrong. Please try again";
}




}
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Package Details</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
<link href="css/font-awesome.css" rel="stylesheet">
<!-- Custom Theme files -->
<script src="js/jquery-1.12.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
<link rel="stylesheet" href="css/jquery-ui.css" />
	<script>
		 new WOW().init();
	</script>
<script src="js/jquery-ui.js"></script>
					<script>
						$(function() {
						$( "#datepicker,#datepicker1" ).datepicker();
						});
					</script>
	  <style>
		.errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
		</style>				
</head>
<body>
<!-- top-header -->
<?php include('includes/header.php');?>
<div class="banner-3">
	<div class="container">
		<h1 class="wow zoomIn animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: zoomIn;">Booking Details</h1>
	</div>
</div>
<!--- /banner ---->
<!--- selectroom ---->
<div class="selectroom">
	<div class="container">	
		  <?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
				else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>


		<div class="selectroom_top">

			<div class="col-md-12 selectroom_right wow fadeInRight animated" data-wow-delay=".5s">


                <form action="" method="post">

                    <div class="form-group">
                        <label for="payment_option">Payment Method</label>
                        <select name="payment_option" id="payment_option" class="form-control" required>
                            <option value="bkash">Bkash</option>

                        </select>
                    </div>

                    <div class="form-group">
                        <label for="account_number">Your Mobile Banking Account Number</label>
                        <input type="number" name="pac_number" id="account_number"  class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="amount">Your Payable Amount</label>
                        <input type="number" name="p_amount" id=""  class="form-control" required>
                    </div>


                    <div class="form-group">
                        <label for="trxid">transaction ID</label>
                        <input type="text" name="p_txid" id="trxid"  class="form-control" required>
                    </div>




                    <div class="form-group">
                        <input type="submit" name="pay" value="Confirm" class="btn btn-xl btn-success">
                        <input type="reset" name="reset-btn" value="Reset" class="btn btn-outline-info">

                    </div>
                </form>
						<div class="clearfix"></div>
				<div class="grand">

				</div>
			</div>

				<div class="clearfix"></div>
		</div>



	</div>
</div>

<!--- /selectroom ---->
<<!--- /footer-top ---->
<?php include('includes/footer.php');?>
<!-- signup -->
<?php include('includes/signup.php');?>			
<!-- //signu -->
<!-- signin -->
<?php include('includes/signin.php');?>			
<!-- //signin -->
<!-- write us -->
<?php include('includes/write-us.php');?>
</body>
</html>