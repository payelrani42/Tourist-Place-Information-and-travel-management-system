
<?php
session_start();
require_once 'class.mail.php';
$reg_user = new MAIL();
//error_reporting(0);
include('includes/config.php');


if(isset($_POST['submit'])){



    $UserType=$_POST['user_type'];
    $mnumber=$_POST['phone'];
    $address=$_POST['address'];

    $fname= trim($_POST['fname']);
//
    if (empty($fname)) {
        $msg = "First name is required";
    }
    else {
        $fname = $reg_user->test_input($fname);
// check if name only contains letters and whitespace
        if (!preg_match("/^[a-zA-Z ]*$/",$fname))
        {
            $msg = "Only letters and white space allowed";
        }
    }


    $email= trim($_POST['email']);

///
    if (empty($email)) {
        $msg = "Email is required";
    }
    else {
        $email = $reg_user->test_input($email);
// check if name only contains letters and whitespace
        if (!filter_var($email, FILTER_VALIDATE_EMAIL))
        {
            $msg = "Invalid email format";
        }
    }

///
    $password= trim($_POST['password']);
    $confirm_password= trim($_POST['confirm_password']);


//

    $password= $reg_user->test_input($password);
    $confirm_password=$reg_user->test_input($confirm_password);


    if($password===$confirm_password){
        $password = password_hash($password, PASSWORD_DEFAULT);

        $code= md5(uniqid(rand()));


        $stmt = $dbh->prepare("SELECT * FROM tblusers WHERE EmailId =:email_id");

        $stmt->execute(array(":email_id"=>$email));


        $row= $stmt->fetch(PDO::FETCH_ASSOC);



        if($stmt->rowCount()>0){
            $msg="
<div>
    <strong>

        Email id allready exists, Please try another one.

    </strong>

</div>

";
        }


        if(empty($msg)){
            
$status="N";
            $sql="INSERT INTO tblusers(UserType,FullName,MobileNumber,Address,EmailId,Password,token_code,status) VALUES(:UserType,:fname,:mnumber,:address,:email,:password,:token_code,:status)";
            $query = $dbh->prepare($sql);

            $query->bindParam(':UserType',$UserType,PDO::PARAM_STR);
            $query->bindParam(':fname',$fname,PDO::PARAM_STR);
            $query->bindParam(':mnumber',$mnumber,PDO::PARAM_STR);
            $query->bindParam(':address',$address,PDO::PARAM_STR);
            $query->bindParam(':email',$email,PDO::PARAM_STR);
            $query->bindParam(':password',$password,PDO::PARAM_STR);
            $query->bindParam(':token_code',$code,PDO::PARAM_STR);
            $query->bindParam(':status',$status,PDO::PARAM_STR);
            ;




            if($query->execute()){


                $id= $dbh->lastInsertId();
                $key= base64_encode($id);

                $id=$key;


                $message="

Hello $fname, Welcome to Travelandbd! <br>

To complete your registration, just click in the following link. <br><br>

<a href='http://localhost/projects/tms/verify.php?id=$id&code=$code'>Click here to activate your id. </a> <br> <br>
Thanks.

";

                $subject="Confirm Your Registration";


                $reg_user->send_mail($email,$message,$subject);

                $msg= "
<div>
    <strong>Success
    </strong>
    We have send an email to $email . <br>
    Please click on the confirmation link in the email to create your account.
</div>
";


                header("refresh:5; signinpage.php");


            }


            else{
                echo "Sorry, Query could not executed due to error";
            }

        }

    }
    else{
        $msg = "
<div>
    <strong> Sorry</strong>

    The password is not match.

</div>

";
    }

}
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Create Account</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<script type="applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/indexStyle.css" rel='stylesheet' type='text/css' />



 
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
<link href="css/font-awesome.css" rel="stylesheet">
<!-- Custom Theme files -->
<script src="js/jquery-1.12.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
        

<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->

<style>
*{
margin:0;
padding:0;
}
body{
	
	width:100%;
	margin-top:0px;
	background-color: #a7c9b2;
}
h1{
text-align:center;
margin-top: 0px;

color: green;
}
h2{
text-align:center;
padding:20px;
}
.register{
	margin-top: 50px;
    background:green;
    width: 600px;
    margin-left: 380px;
    color: white;
    font-size: 18px;
	padding:20px;
	border-radius:10px;
}
#register{
margin-left:90px;
}
label{
color:white;
font-family:sans-serif;
font-size:18px;
}
#name{
width: 378px;
    border: none;
    border-radius: 3px;
    outline: 0;
    padding: 7px;
}



#sub{
	margin-left: 90px;
width:200px;
padding:7px;
font-size:16px;
font-family:sans-serif;
font-weight:600;
border:none;
border-radius:3px;
outline:0;
}
input{
	color: black;
}
</style>



</head>
<body>

<br><br><br>

<?php

if(isset($msg)){
    echo $msg;
}
?>

<!--start signup page--->
<h1>Create Your Account</h1>
<div class="register">
<h2>Sign Up Here</h2>
<form method="post" id="register" action="signuppage.php">
	<label>User Type</label><br>
    <select name="user_type">
		<option>Tourist</option>
	    <option>Travel Agent</option>
    </select>

<br><br>
<label>Full Name</label><br>
<input type="text" name="fname" id="name" placeholder="Enter your Full Name"><br><br>

<label>Phone Number</label><br>

<input type="number" name="phone" id="name" placeholder="Enter your Phone Number"><br><br>

<label>Email</label><br>
<input type="text" name="email" id="name" placeholder="Enter your Email"><br><br>
<label>Address</label><br>
<input type="text" name="address" id="name" placeholder="Enter your Address"><br><br>
<label>Password</label><br>
<input type="password" name="password" id="name" placeholder="Enter your Password"><br><br>
<label>Confirm Password</label><br>
<input type="password" name="confirm_password" id="name" placeholder="Confirm your Password"><br><br>
<input type="submit" name="submit" value="Submit" id="sub">
</form>




</div>

<!--end signup page-->  
<br><br> 
<h3 style="text-align: center;"><a href="index.php" style="color: green;"><b>Back to Home</b></a></h3><br><br>







</body>
</html>