<?php
session_start();
$id = $_REQUEST["id"];
$comment = $_REQUEST["comment"];
$userEmail = $_SESSION["login"];

include 'includes/conn.php';
//echo $id;
//echo $comment;

$insertQuery = "INSERT INTO comments (id, post_id, userEmail, comment)
VALUES (null, '$id', '$userEmail', '$comment')";

$runQuery = $conn->query($insertQuery);

if ($runQuery === true) {
    echo "Insert Success";
    $conn->close();
    header("Location: index.php?c=success");
}else{
    $err = "Error: " .$mysql_qry . "<br>" .$conn->error;
    header("Location: index.php?c=$err");
}

$conn->close();

?>