<?php
session_start();
error_reporting(0);
?>
<html>
    <head>
<!--        // $image= $_FILES["image"];-->
<!---->
<!--        /*echo $dp;*/-->
<!---->
<!--        //echo var_dump($image);-->
<!---->
<!--        //$file_name = $image["name"];-->
<!--        //$tmp_name = $image["tmp_name"];-->
<!--        //echo "<br>Image name: ".$file_name;-->
<!---->
<!--        // move_uploaded_file($tmp_name, "images/upload_image/$file_name");-->

        <title>Upload Image</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <script type="applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
        <link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
        <link href="css/style.css" rel='stylesheet' type='text/css' />
        <link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
        <link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
        <link href='//fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
        <link href="css/font-awesome.css" rel="stylesheet">
        <!-- Custom Theme files -->
        <script src="js/jquery-1.12.0.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <!--animate-->
        <link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
        <script src="js/wow.min.js"></script>
            <script>
                 new WOW().init();
            </script>
        <!--//end-animate-->
    </head>
    
    <body>
        <?php include('includes/header.php');?>
        <br><br><br>
        <div class="container">
            <?php
            $heading="";
           if(!isset($_REQUEST['imagename'])){
                $heading = "Upload Image to Gallery";
            }
            ?>
        
        <?php 
            
                if(isset($_REQUEST['imagename'])){
                $imagename = $_REQUEST['imagename'];
                
                $imagedescription = $_REQUEST['imagedescription'];

                $image=$_FILES['image']['name'];
                $tmp_image=$_FILES['image']['tmp_name'];
                 move_uploaded_file($_FILES['image']['tmp_name'],'images/upload_image/'.$_FILES['image']['name']);


                 require "includes/config.php";
                
                $insertQuery = "INSERT INTO `gallery` (`imageid`, `postBy`, `imagename`, `imagedescription`, `image`, `approved` )  VALUES (NULL, '$userEmail', '$imagename', '$imagedescription', '$image', 'no')";
                
                
                
                $runQuery = $dbh->query($insertQuery);
                $heading = "Upload Success!!!";
//                if ($runQuery === true) {
//                    $heading = "Post Success!!!";
//                    $dbh->close();
//                }else{
//                    $heading = "Something Error :(";
//                }
            }
        ?>
            <h2 class="text-center" style="color: #4db321; margin-top: 10px;"><?php echo $heading ?></h2>
        </div>
        
        <div class="container" style="margin-top:20px; margin-bottom:20px;">

<br>
        <form action="" method="post" enctype="multipart/form-data">
          <div class="form-group">
            
            <input type="text" class="form-control" name="imagename" placeholder="image name" required>
          </div>
            
            

          <div class="form-group">
            
            <input type="text" class="form-control" name="imagedescription" placeholder="image description" required>
          </div>
            
          
            
            <div class="form-group">
            
            <input type="file" class="form-control" name="image" required>
          </div>

          <?php if($_SESSION['login'])
          {?>
            
          <button type="submit" class="btn btn-primary">Upload Image</button>
          <?php } else {?><ul style="list-style-type: none;">
              <li class="sigi" align="center" style="margin-top: 1%">
              <a href="signinpage.php"  class="btn-primary btn" >Login</a></li>
            </ul>
              <?php } ?>
        </form>
        </div>
        
        <?php include('includes/footer.php');?>
    </body>
</html>