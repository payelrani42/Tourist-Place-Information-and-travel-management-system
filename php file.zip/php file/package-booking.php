<?php
session_start();
error_reporting(0);
include('includes/config.php');
//$pid=intval($_GET['pkgid']);
//$sql = "SELECT * from tbltourpackages where PackageId=:pid";
//$query = $dbh->prepare($sql);
//$query -> bindParam(':pid', $pid, PDO::PARAM_STR);
//$query->execute();
//$results=$query->fetchAll(PDO::FETCH_OBJ);
//$cnt=1;
//if($query->rowCount() > 0)
//{
//foreach($results as $result)
//{
//    $Jdate=$result->JourneyDate;
//    $Rdate=$result->ReturnDate;
//}
//}

if(isset($_POST['submit12'])){
    $pid=intval($_POST['package_id']);
    $pquantity=$_POST['package_quantity'];
}

if(isset($_POST['book']))
{
$pid=intval($_POST['package_id']);
$quantity=$_POST['quantity'];
$package_price=$_POST['package_price'];
$total_price=$_POST['total_price'];
    $sql = "SELECT * from tbltourpackages where PackageId=:pid";
    $query = $dbh->prepare($sql);
    $query -> bindParam(':pid', $pid, PDO::PARAM_STR);
    $query->execute();
    $results=$query->fetchAll(PDO::FETCH_OBJ);
    $cnt=1;
    if($query->rowCount() > 0)
    {
        foreach($results as $result)
        {
            $Jdate=$result->JourneyDate;
            $Rdate=$result->ReturnDate;
        }
    }



$useremail=$_SESSION['login'];
$fromdate=$Jdate;
$todate=$Rdate;
//$fromdate=$_POST['fromdate'];
//$todate=$_POST['todate'];
$comment=$_POST['comment'];
$status=0;
$payment_status="pending";
$sql="INSERT INTO tblbooking(PackageId,UserEmail,FromDate,ToDate,Comment,status,booking_quantity,package_price,booking_totalprice,payment_status) VALUES(:pid,:useremail,:fromdate,:todate,:comment,:status,:booking_quantity,:package_price,:booking_totalprice,:payment_status)";
$query = $dbh->prepare($sql);
$query->bindParam(':pid',$pid,PDO::PARAM_STR);
$query->bindParam(':useremail',$useremail,PDO::PARAM_STR);
$query->bindParam(':fromdate',$fromdate,PDO::PARAM_STR);
$query->bindParam(':todate',$todate,PDO::PARAM_STR);
$query->bindParam(':comment',$comment,PDO::PARAM_STR);
$query->bindParam(':status',$status,PDO::PARAM_STR);
$query->bindParam(':booking_quantity',$quantity,PDO::PARAM_STR);
$query->bindParam(':package_price',$package_price,PDO::PARAM_STR);
$query->bindParam(':booking_totalprice',$total_price,PDO::PARAM_STR);
$query->bindParam(':payment_status',$payment_status,PDO::PARAM_STR);

if($query->execute()){
    $last_id = $dbh->lastInsertId();
    $msg="Booked Successfully";


  header("refresh:2; package-payment.php?id=$last_id");
}
else{
    $error="Something went wrong. Please try again";
}




}
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Package Details</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
<link href="css/font-awesome.css" rel="stylesheet">
<!-- Custom Theme files -->
<script src="js/jquery-1.12.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
<link rel="stylesheet" href="css/jquery-ui.css" />
	<script>
		 new WOW().init();
	</script>
<script src="js/jquery-ui.js"></script>
					<script>
						$(function() {
						$( "#datepicker,#datepicker1" ).datepicker();
						});
					</script>
	  <style>
		.errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
		</style>				
</head>
<body>
<!-- top-header -->
<?php include('includes/header.php');?>
<div class="banner-3">
	<div class="container">
		<h1 class="wow zoomIn animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: zoomIn;">Booking Details</h1>
	</div>
</div>
<!--- /banner ---->
<!--- selectroom ---->
<div class="selectroom">
	<div class="container">	
		  <?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
				else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>
<?php 
$pid=intval($_POST['package_id']);
$sql = "SELECT * from tbltourpackages where PackageId=:pid";
$query = $dbh->prepare($sql);
$query -> bindParam(':pid', $pid, PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{	?>


		<div class="selectroom_top">

			<div class="col-md-12 selectroom_right wow fadeInRight animated" data-wow-delay=".5s">

<table class="table table-striped">
    <thead>
    <tr>
        <th class="text-center">Package Name</th>
        <th class="text-center">Package Price(per person)</th>
        <th class="text-center">Quantity</th>
        <th class="text-center">Total Price</th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <td class="text-center"><?php echo htmlentities($result->PackageName);?></td>
        <td class="text-center"><?php echo htmlentities($result->PackagePrice);?></td>
        <td class="text-center"><?php echo $pquantity;?></td>
        <td class="text-center"><?php echo $result->PackagePrice*$pquantity;?></td>
    </tr>
    </tbody>
</table>
                <form method="post" action="">
                    <input type="hidden" name="package_id" value="<?php echo htmlentities($result->PackageId);?>">
                    <input type="hidden" name="package_price" value="<?php echo htmlentities($result->PackagePrice);?>">
                    <input type="hidden" name="quantity" value="<?php echo $pquantity;?>">
                    <input type="hidden" name="total_price" value="<?php echo $result->PackagePrice*$pquantity;?>">
                    <input type="submit" class="btn btn-primary btn-block" name="book" value="Confirm Your Booking">

                </form>
						<div class="clearfix"></div>
				<div class="grand">

				</div>
			</div>

				<div class="clearfix"></div>
		</div>


<?php }} ?>


	</div>
</div>

<!--- /selectroom ---->
<<!--- /footer-top ---->
<?php include('includes/footer.php');?>
<!-- signup -->
<?php include('includes/signup.php');?>			
<!-- //signu -->
<!-- signin -->
<?php include('includes/signin.php');?>			
<!-- //signin -->
<!-- write us -->
<?php include('includes/write-us.php');?>
</body>
</html>