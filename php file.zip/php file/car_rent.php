

<?php
session_start();
error_reporting(0);
if(isset($_SESSION["login"])){
    $userEmail = $_SESSION["login"];
    
}else{
    echo '<script>alert("Login first");</script>';
    header("Location: index.php");
}

?>

<html>
    <head>
        <title>Car Rent</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <script type="applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
        <link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
        <link href="css/style.css" rel='stylesheet' type='text/css' />
        <link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
        <link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
        <link href='//fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
        <link href="css/font-awesome.css" rel="stylesheet">
        <!-- Custom Theme files -->
        <script src="js/jquery-1.12.0.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <!--animate-->
        <link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
        <script src="js/wow.min.js"></script>
            <script>
                 new WOW().init();
            </script>
        <!--//end-animate-->
    </head>
    
    <body>
        <?php include('includes/header.php');?>
        
        <div class="container">
            <?php
            $heading="";
            if(!isset($_REQUEST['user_name'])){
                $heading = "Rent a Car";
            }
            ?>
        
        <?php 
            if(isset($_REQUEST['user_name'])){
                $user_name = $_REQUEST['user_name'];
                $pick_up_point = $_REQUEST['pick_up_point'];
                $destination_point = $_REQUEST['destination_point'];
                $car_type = $_REQUEST['car_type'];
                $phone_number = $_REQUEST['phone_number'];
                $pick_up_time = $_REQUEST['pick_up_time'];

                
                require 'includes/conn.php';
                
                $insertQuery = "INSERT INTO `carrent` (`id`, `postBy`, `user_name`, `pick_up_point`, `destination_point`,`car_type`,`phone_number`, `approved`,`pick_up_time` ) 
                VALUES (NULL, '$userEmail', '$user_name', '$pick_up_point', '$destination_point', '$car_type', '$phone_number' ,'no','$pick_up_time')";
                
                
                $result = mysqli_query($conn, $insertQuery);
                //$runQuery = $dbh->query($insertQuery);
                
                if ($result === true) {
                    $heading = "Submit Success!!!";
                }else{
                    $heading = "Error: " .$mysql_qry . "<br>" .$conn->error;
                }
            }
        ?>
            <h2 class="text-center" style="color: #4db321; margin-top: 10px;"><?php echo $heading ?></h2>
        </div>
        
        <div class="container" style="margin-top:20px; margin-bottom:20px;">


        <form action="?" method="post">
          <div class="form-group">
            <label>User Name:</label>
            <input type="text" class="form-control" name="user_name" placeholder="user name" required>
          </div>
            
            <div class="form-group">
            <label>Pick up Point:</label>
            <input type="text" class="form-control" name="pick_up_point" placeholder="pick up point" required>
          </div>

          <div class="form-group">
            <label>Destination Point:</label>
            <input type="text" class="form-control" name="destination_point" placeholder="destination point" required>
          </div>
            
          <div class="form-group">
            <label>Car Type/Quantity:</label>
            <input type="text" class="form-control" name="car_type" placeholder="Which type of car you need and how many car you need?" required>
          </div>
            
          <div class="form-group">
            <label>Phone Number:</label>
            <input type="text" class="form-control" name="phone_number" placeholder="enter valid phone number for contact you" required>
          </div>

          <div class="form-group">
            <label>Pick up Time:</label>
            <input type="time" class="form-control" name="pick_up_time" placeholder="pick up time" required>
          </div>

            
          <button type="submit" class="btn btn-primary">Submit</button>
        </form>
        </div>
        
        <?php include('includes/footer.php');?>
    </body>
</html>